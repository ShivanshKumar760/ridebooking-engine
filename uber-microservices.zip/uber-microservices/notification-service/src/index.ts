// notification-service/src/index.ts

import 'dotenv/config';
import express from 'express';
import { createLogger } from '../../shared/utils/logger';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import {
  RideBookedEvent, RideAcceptedEvent, RideStartedEvent,
  RideCompletedEvent, RideCancelledEvent, PaymentCompletedEvent,
  ServiceEvent,
} from '../../shared/types';

const logger = createLogger('notification-service');
const app = express();
app.use(express.json());

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'notification-service' }));

// ─── Notification template helpers ───────────────────────────────────
const notify = (to: string, type: string, title: string, body: string, data?: Record<string, unknown>) => {
  // In production: send via FCM / APNs / SMS (Twilio) / email (SendGrid)
  // For now: structured log that shows exactly what would be sent
  logger.info(`📲 NOTIFY [${type}] → ${to}`, { title, body, data });
};

// ─── RIDE_BOOKED → notify nearby drivers ─────────────────────────────
eventBus.subscribe<RideBookedEvent>(EVENTS.RIDE_BOOKED, ({ payload }: ServiceEvent<RideBookedEvent>) => {
  payload.nearbyDriverUserIds.forEach((driverUserId) => {
    notify(
      driverUserId,
      'push',
      '🚗 New Ride Request',
      `Pickup: ${payload.pickupAddress} → ${payload.dropoffAddress} | ₹${payload.estimatedFare.toFixed(0)}`,
      { rideId: payload.rideId, type: 'RIDE_REQUEST' }
    );
  });
  logger.info(`Notified ${payload.nearbyDriverUserIds.length} drivers for ride ${payload.rideId}`);
});

// ─── RIDE_ACCEPTED → notify passenger ────────────────────────────────
eventBus.subscribe<RideAcceptedEvent>(EVENTS.RIDE_ACCEPTED, ({ payload }: ServiceEvent<RideAcceptedEvent>) => {
  notify(
    payload.driverUserId,
    'sms',
    'Ride Accepted',
    `Your driver ${payload.driverName} (${payload.vehicleNumber}) is on the way. ETA: ${payload.etaMinutes} mins. OTP: ${payload.otp}`
  );
  logger.info(`Notified passenger for ride ${payload.rideId}: driver ${payload.driverName} assigned`);
});

// ─── RIDE_STARTED → notify passenger ─────────────────────────────────
eventBus.subscribe<RideStartedEvent>(EVENTS.RIDE_STARTED, ({ payload }: ServiceEvent<RideStartedEvent>) => {
  notify(
    'passenger',
    'push',
    '🚦 Ride Started',
    `Your ride has begun. Enjoy the trip!`,
    { rideId: payload.rideId }
  );
});

// ─── RIDE_COMPLETED → notify both parties ────────────────────────────
eventBus.subscribe<RideCompletedEvent>(EVENTS.RIDE_COMPLETED, ({ payload }: ServiceEvent<RideCompletedEvent>) => {
  notify(
    'passenger',
    'push',
    '✅ Ride Completed',
    `Fare: ₹${payload.finalFare.toFixed(2)} | ${payload.distanceKm.toFixed(1)} km | ${payload.durationMinutes} mins. Please rate your driver!`,
    { rideId: payload.rideId }
  );
  notify(
    'driver',
    'push',
    '✅ Ride Completed',
    `Earned ₹${payload.finalFare.toFixed(2)} for ${payload.distanceKm.toFixed(1)} km ride.`,
    { rideId: payload.rideId }
  );
});

// ─── RIDE_CANCELLED ───────────────────────────────────────────────────
eventBus.subscribe<RideCancelledEvent>(EVENTS.RIDE_CANCELLED, ({ payload }: ServiceEvent<RideCancelledEvent>) => {
  const target = payload.cancelledBy === 'passenger' ? 'driver' : 'passenger';
  notify(
    target,
    'push',
    '❌ Ride Cancelled',
    `Reason: ${payload.reason}`,
    { rideId: payload.rideId }
  );
  if (payload.cancelledBy === 'system') {
    notify('passenger', 'push', '😔 No Drivers Found', 'No nearby drivers accepted your ride. Please try again.', { rideId: payload.rideId });
  }
});

// ─── PAYMENT_COMPLETED ────────────────────────────────────────────────
eventBus.subscribe<PaymentCompletedEvent>(EVENTS.PAYMENT_COMPLETED, ({ payload }: ServiceEvent<PaymentCompletedEvent>) => {
  notify(
    'passenger',
    'push',
    '💳 Payment Confirmed',
    `₹${payload.amount.toFixed(2)} paid via ${payload.gateway}. Transaction: ${payload.transactionId.slice(0, 8)}...`,
    { rideId: payload.rideId }
  );
});

// ─── Wildcard logger for all events ──────────────────────────────────
eventBus.subscribe<unknown>('*', ({ event, serviceOrigin, timestamp }: ServiceEvent<unknown>) => {
  logger.debug(`Event received: ${event} from ${serviceOrigin} at ${timestamp}`);
});

const PORT = parseInt(process.env.PORT || '3006', 10);
app.listen(PORT, () => logger.info(`Notification service on :${PORT}`));
