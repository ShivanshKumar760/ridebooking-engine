// payment-service/src/index.ts

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import crypto from 'crypto';
import { createLogger } from '../../shared/utils/logger';
import { authenticate, requireRole, errorHandler, AppError } from '../../shared/middleware/auth';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import { withTransaction } from '../../shared/utils/database';
import { PaymentGateway, PaymentCompletedEvent } from '../../shared/types';

const logger = createLogger('payment-service');
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

// Raw body for Stripe webhook signature verification
app.use((req, res, next) => {
  if (req.path === '/api/payments/webhooks/stripe') {
    express.raw({ type: 'application/json' })(req, res, next);
  } else {
    express.json()(req, res, next);
  }
});
app.use(helmet()); app.use(cors()); app.use(compression());

// ─── Inject user from gateway headers ───────────────────────────────
app.use((req: Request, _res: Response, next: NextFunction) => {
  const userId = req.headers['x-user-id'] as string;
  const role   = req.headers['x-user-role'] as string;
  if (userId && role) req.user = { userId, role: role as 'passenger' | 'driver' };
  next();
});

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'payment-service' }));

// ─── Determine active gateway ─────────────────────────────────────────
const getGateway = (): PaymentGateway => {
  const gw = process.env.PAYMENT_GATEWAY || 'mock';
  return (['razorpay', 'stripe', 'mock'] as PaymentGateway[]).includes(gw as PaymentGateway)
    ? (gw as PaymentGateway)
    : 'mock';
};

// ─── Razorpay order creation ──────────────────────────────────────────
const createRazorpayOrder = async (rideId: string, amount: number) => {
  try {
    const Razorpay = (await import('razorpay')).default;
    const rz = new Razorpay({
      key_id:     process.env.RAZORPAY_KEY_ID     as string,
      key_secret: process.env.RAZORPAY_KEY_SECRET as string,
    });
    const order = await rz.orders.create({
      amount: Math.round(amount * 100),
      currency: 'INR',
      receipt: `ride_${rideId}`,
      notes: { rideId },
    });
    return { gateway: 'razorpay' as PaymentGateway, gatewayOrderId: order.id, clientSecret: undefined };
  } catch (err) {
    logger.error('Razorpay order failed, falling back to mock', { err });
    return createMockOrder(rideId);
  }
};

const verifyRazorpaySignature = (orderId: string, paymentId: string, signature: string): boolean => {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET as string)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');
  return expected === signature;
};

// ─── Stripe PaymentIntent creation ───────────────────────────────────
const createStripeIntent = async (rideId: string, amount: number) => {
  try {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2025-03-31.basil' });
    const intent = await stripe.paymentIntents.create({
      amount: Math.round(amount * 100),
      currency: 'inr',
      metadata: { rideId },
      automatic_payment_methods: { enabled: true },
    });
    return { gateway: 'stripe' as PaymentGateway, gatewayOrderId: intent.id, clientSecret: intent.client_secret ?? undefined };
  } catch (err) {
    logger.error('Stripe intent failed, falling back to mock', { err });
    return createMockOrder(rideId);
  }
};

// ─── Mock gateway ─────────────────────────────────────────────────────
const createMockOrder = (_rideId: string) => ({
  gateway: 'mock' as PaymentGateway,
  gatewayOrderId: `mock_order_${Date.now()}_${Math.random().toString(36).slice(2)}`,
  clientSecret: undefined,
});

// ─── Confirm payment in DB ────────────────────────────────────────────
const confirmPaymentInDB = async (
  rideId: string,
  gateway: PaymentGateway,
  gatewayOrderId: string,
  gatewayPaymentId: string,
  gatewaySignature?: string
): Promise<string> => {
  return withTransaction(pool, async (client) => {
    const { rows: [tx] } = await client.query(
      `UPDATE payment_transactions
         SET gateway_payment_id=$1, gateway_signature=$2, status='completed', updated_at=NOW()
       WHERE ride_id=$3 AND gateway=$4
       RETURNING id`,
      [gatewayPaymentId, gatewaySignature ?? null, rideId, gateway]
    );
    if (!tx) throw new AppError('Transaction record not found', 404);

    await client.query(
      `UPDATE rides SET payment_status='completed', payment_id=$1, payment_gateway=$2, payment_method=$3, updated_at=NOW() WHERE id=$4`,
      [gatewayPaymentId, gateway, gateway, rideId]
    );

    // Fetch amount for event
    const { rows: [ride] } = await client.query(`SELECT final_fare FROM rides WHERE id=$1`, [rideId]);
    eventBus.publish<PaymentCompletedEvent>(EVENTS.PAYMENT_COMPLETED, {
      rideId, transactionId: tx.id,
      amount: ride?.final_fare ?? 0,
      gateway, paidAt: new Date().toISOString(),
    }, 'payment-service');

    logger.info(`Payment confirmed: ride=${rideId} gateway=${gateway}`);
    return tx.id;
  });
};

// ─── POST /api/payments/rides/:rideId/order ───────────────────────────
app.post('/api/payments/rides/:rideId/order',
  authenticate, requireRole('passenger'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;

      // Verify passenger owns this ride
      const { rows: [ride] } = await pool.query(
        `SELECT r.id, r.final_fare, r.estimated_fare, r.payment_status
         FROM rides r JOIN passengers p ON r.passenger_id=p.id
         WHERE r.id=$1 AND p.user_id=$2 AND r.status='completed'`,
        [rideId, userId]
      );
      if (!ride) throw new AppError('Ride not found or not completed', 404);
      if (ride.payment_status === 'completed') throw new AppError('Already paid', 409);

      const amount = parseFloat(ride.final_fare || ride.estimated_fare);
      const gw = getGateway();

      let orderData;
      if (gw === 'razorpay') {
        orderData = await createRazorpayOrder(rideId, amount);
      } else if (gw === 'stripe') {
        orderData = await createStripeIntent(rideId, amount);
      } else {
        orderData = createMockOrder(rideId);
      }

      // Persist pending transaction
      await pool.query(
        `INSERT INTO payment_transactions (ride_id, gateway, gateway_order_id, amount, currency, status)
         VALUES ($1,$2,$3,$4,'INR','pending')
         ON CONFLICT DO NOTHING`,
        [rideId, orderData.gateway, orderData.gatewayOrderId, amount]
      );
      await pool.query(`UPDATE rides SET payment_status='processing' WHERE id=$1`, [rideId]);

      res.json({
        success: true,
        data: {
          orderId: rideId,
          amount,
          currency: 'INR',
          gateway: orderData.gateway,
          gatewayOrderId: orderData.gatewayOrderId,
          clientSecret: orderData.clientSecret,
        },
      });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/payments/rides/:rideId/verify ─────────────────────────
app.post('/api/payments/rides/:rideId/verify',
  authenticate, requireRole('passenger'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { rideId } = req.params;
      const { gatewayOrderId, gatewayPaymentId, gatewaySignature, gateway } = req.body as {
        gatewayOrderId: string; gatewayPaymentId: string;
        gatewaySignature?: string; gateway: PaymentGateway;
      };

      if (gateway === 'razorpay') {
        if (!gatewaySignature) throw new AppError('Signature required for Razorpay', 400);
        if (!verifyRazorpaySignature(gatewayOrderId, gatewayPaymentId, gatewaySignature)) {
          throw new AppError('Signature verification failed', 400);
        }
      }
      // Stripe: webhook handles authoritative confirmation; this is client acknowledgement
      // Mock: always passes

      const transactionId = await confirmPaymentInDB(rideId, gateway, gatewayOrderId, gatewayPaymentId, gatewaySignature);
      res.json({ success: true, data: { transactionId } });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/payments/rides/:rideId/mock ───────────────────────────
app.post('/api/payments/rides/:rideId/mock',
  authenticate, requireRole('passenger'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;

      const { rows: [ride] } = await pool.query(
        `SELECT r.id, r.payment_status FROM rides r JOIN passengers p ON r.passenger_id=p.id
         WHERE r.id=$1 AND p.user_id=$2 AND r.status='completed'`,
        [rideId, userId]
      );
      if (!ride) throw new AppError('Ride not found or not completed', 404);
      if (ride.payment_status === 'completed') throw new AppError('Already paid', 409);

      const mockOrderId  = `mock_order_${rideId}_${Date.now()}`;
      const mockPayId    = `mock_pay_${Date.now()}_${Math.random().toString(36).slice(2)}`;

      // Ensure transaction row exists
      const { rows: [existing] } = await pool.query(
        `SELECT id FROM payment_transactions WHERE ride_id=$1`, [rideId]
      );
      if (!existing) {
        const { rows: [r] } = await pool.query(`SELECT final_fare, estimated_fare FROM rides WHERE id=$1`, [rideId]);
        await pool.query(
          `INSERT INTO payment_transactions (ride_id, gateway, gateway_order_id, amount, currency, status)
           VALUES ($1,'mock',$2,$3,'INR','pending')`,
          [rideId, mockOrderId, parseFloat(r.final_fare || r.estimated_fare)]
        );
        await pool.query(`UPDATE rides SET payment_status='processing' WHERE id=$1`, [rideId]);
      }

      const transactionId = await confirmPaymentInDB(rideId, 'mock', mockOrderId, mockPayId);
      logger.info(`Mock payment completed: ride=${rideId}`);
      res.json({ success: true, message: 'Mock payment completed', data: { transactionId } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/payments/rides/:rideId/status ───────────────────────────
app.get('/api/payments/rides/:rideId/status',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;
      const { rows: [tx] } = await pool.query(
        `SELECT pt.*, r.final_fare, r.payment_status
         FROM payment_transactions pt
         JOIN rides r ON pt.ride_id=r.id
         JOIN passengers p ON r.passenger_id=p.id
         WHERE pt.ride_id=$1 AND p.user_id=$2
         ORDER BY pt.created_at DESC LIMIT 1`,
        [rideId, userId]
      );
      if (!tx) throw new AppError('Payment record not found', 404);
      res.json({ success: true, data: tx });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/payments/webhooks/stripe ──────────────────────────────
app.post('/api/payments/webhooks/stripe', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const sig = req.headers['stripe-signature'];
    if (!sig) throw new AppError('Missing stripe-signature header', 400);

    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(process.env.STRIPE_SECRET_KEY as string, { apiVersion: '2025-03-31.basil' });

    const event = stripe.webhooks.constructEvent(
      req.body as Buffer,
      sig as string,
      process.env.STRIPE_WEBHOOK_SECRET as string
    );

    if (event.type === 'payment_intent.succeeded') {
      const intent = event.data.object as unknown as { id: string; metadata: { rideId?: string } };
      const rideId = intent.metadata?.rideId;
      if (rideId) {
        await confirmPaymentInDB(rideId, 'stripe', intent.id, intent.id);
      }
    }

    res.json({ received: true });
  } catch (e) { next(e); }
});

app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT || '3004', 10);
app.listen(PORT, () => logger.info(`Payment service on :${PORT}`));
process.on('SIGTERM', () => pool.end().then(() => process.exit(0)));
