// payment-service/src/migrate.ts
import 'dotenv/config';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const run = async () => {
  await pool.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`);

  // Rides reference (denormalized copy for payment service autonomy)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS rides (
      id UUID PRIMARY KEY,
      passenger_id UUID NOT NULL,
      final_fare DECIMAL(10,2),
      estimated_fare DECIMAL(10,2) NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'searching',
      payment_status VARCHAR(20) DEFAULT 'pending',
      payment_id TEXT,
      payment_gateway VARCHAR(20),
      payment_method VARCHAR(50),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS passengers (
      id UUID PRIMARY KEY,
      user_id UUID UNIQUE NOT NULL
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS payment_transactions (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      ride_id UUID NOT NULL,
      gateway VARCHAR(20) NOT NULL CHECK (gateway IN ('razorpay','stripe','mock')),
      gateway_order_id TEXT,
      gateway_payment_id TEXT,
      gateway_signature TEXT,
      amount DECIMAL(10,2) NOT NULL,
      currency VARCHAR(5) DEFAULT 'INR',
      status VARCHAR(20) DEFAULT 'pending',
      metadata JSONB,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE(ride_id, gateway)
    )
  `);

  await pool.query(`CREATE INDEX IF NOT EXISTS idx_pay_tx_ride ON payment_transactions(ride_id)`);

  console.log('✅ Payment service migrations complete');
  await pool.end();
};

run().catch((e) => { console.error(e); process.exit(1); });
