// auth-service/src/index.ts

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { body, validationResult } from 'express-validator';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { Pool } from 'pg';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import { createLogger } from '../../shared/utils/logger';
import { AppError, authenticate, errorHandler } from '../../shared/middleware/auth';
import { JwtPayload } from '../../shared/types';

const logger = createLogger('auth-service');
const app = express();

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet()); app.use(cors()); app.use(compression()); app.use(express.json());

// ─── Helpers ─────────────────────────────────────────────────────────
const hashPw  = (pw: string) => bcrypt.hash(pw, 12);
const checkPw = (pw: string, hash: string) => bcrypt.compare(pw, hash);

const generateTokens = (payload: Omit<JwtPayload, 'iat' | 'exp'>) => ({
  accessToken:  jwt.sign(payload, process.env.JWT_SECRET as string,         { expiresIn: process.env.JWT_EXPIRES_IN  || '1h' } as jwt.SignOptions),
  refreshToken: jwt.sign(payload, process.env.JWT_REFRESH_SECRET as string, { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' } as jwt.SignOptions),
});

const sanitize = (u: Record<string, unknown>) => {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { password_hash, refresh_token, ...safe } = u; return safe;
};

const validate = (rules: ReturnType<typeof body>[]) =>
  async (req: Request, res: Response, next: NextFunction) => {
    await Promise.all(rules.map(r => r.run(req)));
    const errs = validationResult(req);
    if (!errs.isEmpty()) {
      return res.status(400).json({ success: false, errors: errs.array().map(e => ({ field: e.type === 'field' ? e.path : 'unknown', message: e.msg })) });
    }
    next();
  };

const pwRules = [
  body('password').isLength({ min: 8 }).withMessage('Min 8 chars')
    .matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/).withMessage('Needs upper, lower, digit'),
];
const commonReg = [
  body('email').isEmail().normalizeEmail(),
  body('phone').matches(/^\+?[1-9]\d{9,14}$/),
  body('name').trim().isLength({ min: 2, max: 100 }),
  ...pwRules,
];

// ─── Health ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'auth-service' }));

// ─── Register Passenger ───────────────────────────────────────────────
app.post('/api/auth/register/passenger',
  validate(commonReg),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, phone, name, password } = req.body;
      const hash = await hashPw(password);
      const { rows: [user] } = await pool.query(
        `INSERT INTO users (email,phone,name,password_hash,role) VALUES($1,$2,$3,$4,'passenger') RETURNING *`,
        [email, phone, name, hash]
      );
      await pool.query(`INSERT INTO passengers (user_id) VALUES($1)`, [user.id]);
      const tokens = generateTokens({ userId: user.id, role: 'passenger' });
      await pool.query(`UPDATE users SET refresh_token=$1 WHERE id=$2`, [tokens.refreshToken, user.id]);
      logger.info(`Passenger registered: ${email}`);
      res.status(201).json({ success: true, data: { user: sanitize(user), ...tokens } });
    } catch (e) { next(e); }
  }
);

// ─── Register Driver ──────────────────────────────────────────────────
app.post('/api/auth/register/driver',
  validate([
    ...commonReg,
    body('vehicleType').isIn(['bike','auto','cab','premium']),
    body('vehicleNumber').trim().isLength({ min: 4, max: 20 }),
    body('vehicleModel').trim().isLength({ min: 2, max: 100 }),
    body('licenseNumber').trim().isLength({ min: 5, max: 50 }),
  ]),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, phone, name, password, vehicleType, vehicleNumber, vehicleModel, licenseNumber } = req.body;
      const hash = await hashPw(password);
      const { rows: [user] } = await pool.query(
        `INSERT INTO users (email,phone,name,password_hash,role) VALUES($1,$2,$3,$4,'driver') RETURNING *`,
        [email, phone, name, hash]
      );
      await pool.query(
        `INSERT INTO drivers (user_id,vehicle_type,vehicle_number,vehicle_model,license_number) VALUES($1,$2,$3,$4,$5)`,
        [user.id, vehicleType, vehicleNumber.toUpperCase(), vehicleModel, licenseNumber]
      );
      const tokens = generateTokens({ userId: user.id, role: 'driver' });
      await pool.query(`UPDATE users SET refresh_token=$1 WHERE id=$2`, [tokens.refreshToken, user.id]);
      logger.info(`Driver registered: ${email}`);
      res.status(201).json({ success: true, data: { user: sanitize(user), ...tokens } });
    } catch (e) { next(e); }
  }
);

// ─── Login ────────────────────────────────────────────────────────────
app.post('/api/auth/login',
  validate([body('email').isEmail().normalizeEmail(), body('password').notEmpty()]),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email, password } = req.body;
      const { rows } = await pool.query(
        `SELECT u.*,
          CASE WHEN u.role='driver' THEN d.id ELSE p.id END as profile_id,
          CASE WHEN u.role='driver' THEN d.is_available ELSE NULL END as is_available,
          CASE WHEN u.role='driver' THEN d.vehicle_type ELSE NULL END as vehicle_type
         FROM users u
         LEFT JOIN drivers d ON u.id=d.user_id AND u.role='driver'
         LEFT JOIN passengers p ON u.id=p.user_id AND u.role='passenger'
         WHERE u.email=$1 AND u.is_active=true`,
        [email]
      );
      if (!rows[0] || !(await checkPw(password, rows[0].password_hash))) {
        throw new AppError('Invalid credentials', 401);
      }
      const user = rows[0];
      const tokens = generateTokens({ userId: user.id, role: user.role });
      await pool.query(`UPDATE users SET refresh_token=$1 WHERE id=$2`, [tokens.refreshToken, user.id]);
      res.json({ success: true, data: { user: sanitize(user), ...tokens } });
    } catch (e) { next(e); }
  }
);

// ─── Refresh token ────────────────────────────────────────────────────
app.post('/api/auth/refresh',
  validate([body('refreshToken').notEmpty()]),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { refreshToken } = req.body;
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET as string) as JwtPayload;
      const { rows } = await pool.query(
        `SELECT * FROM users WHERE id=$1 AND refresh_token=$2 AND is_active=true`,
        [decoded.userId, refreshToken]
      );
      if (!rows[0]) throw new AppError('Invalid refresh token', 401);
      const tokens = generateTokens({ userId: decoded.userId, role: decoded.role });
      await pool.query(`UPDATE users SET refresh_token=$1 WHERE id=$2`, [tokens.refreshToken, decoded.userId]);
      res.json({ success: true, data: tokens });
    } catch (e) { next(e); }
  }
);

// ─── Logout ───────────────────────────────────────────────────────────
app.post('/api/auth/logout', authenticate, async (req: Request, res: Response, next: NextFunction) => {
  try {
    await pool.query(`UPDATE users SET refresh_token=NULL WHERE id=$1`, [req.user!.userId]);
    res.json({ success: true, message: 'Logged out' });
  } catch (e) { next(e); }
});

// ─── Get profile ──────────────────────────────────────────────────────
app.get('/api/auth/me', authenticate, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { userId, role } = req.user!;
    const { rows } = role === 'driver'
      ? await pool.query(
          `SELECT u.id,u.email,u.phone,u.name,u.role,u.is_active,
                  d.id as driver_id,d.vehicle_type,d.vehicle_number,d.vehicle_model,
                  d.license_number,d.rating,d.total_rides,d.is_available
           FROM users u JOIN drivers d ON u.id=d.user_id WHERE u.id=$1`, [userId])
      : await pool.query(
          `SELECT u.id,u.email,u.phone,u.name,u.role,u.is_active,
                  p.id as passenger_id,p.rating,p.total_rides
           FROM users u JOIN passengers p ON u.id=p.user_id WHERE u.id=$1`, [userId]);
    if (!rows[0]) throw new AppError('User not found', 404);
    res.json({ success: true, data: rows[0] });
  } catch (e) { next(e); }
});

// ─── Internal: verify token (called by other services) ───────────────
app.get('/api/auth/verify', authenticate, (req: Request, res: Response) => {
  res.json({ success: true, data: req.user });
});

app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT || '3001', 10);
app.listen(PORT, () => logger.info(`Auth service on :${PORT}`));

process.on('SIGTERM', () => pool.end().then(() => process.exit(0)));
