// driver-service/src/index.ts

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import { createLogger } from '../../shared/utils/logger';
import { authenticate, requireRole, errorHandler, AppError } from '../../shared/middleware/auth';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import { RideAcceptedEvent, RideStartedEvent, RideCompletedEvent } from '../../shared/types';

const logger = createLogger('driver-service');
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet()); app.use(cors()); app.use(compression()); app.use(express.json());

// ─── Inject user from gateway headers (already verified by gateway) ──
app.use((req: Request, _res: Response, next: NextFunction) => {
  const userId = req.headers['x-user-id'] as string;
  const role   = req.headers['x-user-role'] as string;
  if (userId && role) {
    req.user = { userId, role: role as 'passenger' | 'driver' };
  }
  next();
});

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'driver-service' }));

// ─── PUT /api/drivers/availability ────────────────────────────────────
app.put('/api/drivers/availability',
  authenticate, requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { isAvailable } = req.body;
      const { rows } = await pool.query(
        `UPDATE drivers SET is_available=$1, updated_at=NOW() WHERE user_id=$2 RETURNING is_available`,
        [isAvailable, req.user!.userId]
      );
      if (!rows[0]) throw new AppError('Driver not found', 404);
      res.json({ success: true, data: { isAvailable: rows[0].is_available } });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/drivers/rides/:rideId/accept ───────────────────────────
app.post('/api/drivers/rides/:rideId/accept',
  authenticate, requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;

      const { rows: [driver] } = await pool.query(
        `SELECT d.*, u.name, u.phone FROM drivers d JOIN users u ON d.user_id=u.id WHERE d.user_id=$1`,
        [userId]
      );
      if (!driver) throw new AppError('Driver not found', 404);
      if (!driver.is_available) throw new AppError('Driver not available', 400);

      // Update ride (calls ride service via internal fetch or direct DB in monorepo-style microservices)
      // Here we publish the event; ride service listens and updates ride status
      const rideServiceUrl = process.env.RIDE_SERVICE_URL || 'http://localhost:3003';
      const rideRes = await fetch(`${rideServiceUrl}/internal/rides/${rideId}/assign`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Internal-Secret': process.env.INTERNAL_SECRET || 'internal' },
        body: JSON.stringify({ driverId: driver.id }),
      });

      if (!rideRes.ok) {
        const err = await rideRes.json() as { message?: string };
        throw new AppError(err.message || 'Failed to assign ride', 409);
      }

      const { ride } = await rideRes.json() as { ride: Record<string, unknown> };

      // Mark driver unavailable
      await pool.query(`UPDATE drivers SET is_available=false WHERE id=$1`, [driver.id]);

      // Get ETA from location service
      let etaMinutes = 5;
      try {
        const locRes = await fetch(
          `${process.env.LOCATION_SERVICE_URL || 'http://localhost:3005'}/api/location/eta?` +
          `driverLat=${driver.current_latitude}&driverLng=${driver.current_longitude}&` +
          `pickupLat=${ride.pickup_latitude}&pickupLng=${ride.pickup_longitude}`
        );
        if (locRes.ok) {
          const locData = await locRes.json() as { data: { etaMinutes: number } };
          etaMinutes = locData.data.etaMinutes;
        }
      } catch { /* use default */ }

      // Publish event → notification service + gateway/socket
      eventBus.publish<RideAcceptedEvent>(EVENTS.RIDE_ACCEPTED, {
        rideId,
        driverId: driver.id,
        driverUserId: userId,
        driverName: driver.name,
        driverPhone: driver.phone,
        vehicleType: driver.vehicle_type,
        vehicleNumber: driver.vehicle_number,
        vehicleModel: driver.vehicle_model,
        driverRating: driver.rating,
        driverLocation: { latitude: driver.current_latitude, longitude: driver.current_longitude },
        otp: ride.otp as string,
        etaMinutes,
      }, 'driver-service');

      logger.info(`Driver ${driver.id} accepted ride ${rideId}`);
      res.json({ success: true, message: 'Ride accepted', data: { etaMinutes } });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/drivers/rides/:rideId/start ────────────────────────────
app.post('/api/drivers/rides/:rideId/start',
  authenticate, requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;
      const { otp } = req.body;

      const { rows: [driver] } = await pool.query(`SELECT id FROM drivers WHERE user_id=$1`, [userId]);
      if (!driver) throw new AppError('Driver not found', 404);

      const rideServiceUrl = process.env.RIDE_SERVICE_URL || 'http://localhost:3003';
      const rideRes = await fetch(`${rideServiceUrl}/internal/rides/${rideId}/start`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Internal-Secret': process.env.INTERNAL_SECRET || 'internal' },
        body: JSON.stringify({ driverId: driver.id, otp }),
      });

      if (!rideRes.ok) {
        const err = await rideRes.json() as { message?: string };
        throw new AppError(err.message || 'Failed to start ride', 400);
      }

      eventBus.publish<RideStartedEvent>(EVENTS.RIDE_STARTED, {
        rideId,
        startedAt: new Date().toISOString(),
      }, 'driver-service');

      res.json({ success: true, message: 'Ride started' });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/drivers/rides/:rideId/complete ─────────────────────────
app.post('/api/drivers/rides/:rideId/complete',
  authenticate, requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;

      const { rows: [driver] } = await pool.query(`SELECT id FROM drivers WHERE user_id=$1`, [userId]);
      if (!driver) throw new AppError('Driver not found', 404);

      const rideServiceUrl = process.env.RIDE_SERVICE_URL || 'http://localhost:3003';
      const rideRes = await fetch(`${rideServiceUrl}/internal/rides/${rideId}/complete`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Internal-Secret': process.env.INTERNAL_SECRET || 'internal' },
        body: JSON.stringify({ driverId: driver.id }),
      });

      if (!rideRes.ok) {
        const err = await rideRes.json() as { message?: string };
        throw new AppError(err.message || 'Failed to complete ride', 400);
      }

      const { finalFare, distanceKm, durationMinutes } = await rideRes.json() as {
        finalFare: number; distanceKm: number; durationMinutes: number;
      };

      // Free up driver
      await pool.query(`UPDATE drivers SET is_available=true, total_rides=total_rides+1 WHERE id=$1`, [driver.id]);

      eventBus.publish(EVENTS.RIDE_COMPLETED, {
        rideId, finalFare, distanceKm, durationMinutes, completedAt: new Date().toISOString(),
      }, 'driver-service');

      res.json({ success: true, data: { finalFare, distanceKm, durationMinutes } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/drivers/rides ───────────────────────────────────────────
app.get('/api/drivers/rides',
  authenticate, requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const page = parseInt((req.query.page as string) || '1');
      const limit = parseInt((req.query.limit as string) || '10');
      const offset = (page - 1) * limit;

      const rideServiceUrl = process.env.RIDE_SERVICE_URL || 'http://localhost:3003';
      const { rows: [driver] } = await pool.query(`SELECT id FROM drivers WHERE user_id=$1`, [userId]);
      if (!driver) throw new AppError('Driver not found', 404);

      const r = await fetch(
        `${rideServiceUrl}/internal/rides/driver/${driver.id}?page=${page}&limit=${limit}&offset=${offset}`,
        { headers: { 'X-Internal-Secret': process.env.INTERNAL_SECRET || 'internal' } }
      );
      const data = await r.json();
      res.json(data);
    } catch (e) { next(e); }
  }
);

app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT || '3002', 10);
app.listen(PORT, () => logger.info(`Driver service on :${PORT}`));

process.on('SIGTERM', () => pool.end().then(() => process.exit(0)));
