#!/bin/bash
# scripts/setup-osrm.sh
# Downloads and pre-processes map data for OSRM
# Usage: ./scripts/setup-osrm.sh [region]
# Regions: india (default), mumbai, delhi, bangalore
# Full region list: https://download.geofabrik.de/

set -e

REGION=${1:-india}
DATA_DIR="./osrm-data"
mkdir -p "$DATA_DIR"

declare -A REGION_URLS=(
  ["india"]="https://download.geofabrik.de/asia/india-latest.osm.pbf"
  ["mumbai"]="https://download.geofabrik.de/asia/india/maharashtra-latest.osm.pbf"
  ["delhi"]="https://download.geofabrik.de/asia/india/delhi-latest.osm.pbf"
  ["bangalore"]="https://download.geofabrik.de/asia/india/karnataka-latest.osm.pbf"
  ["uk"]="https://download.geofabrik.de/europe/great-britain-latest.osm.pbf"
  ["usa"]="https://download.geofabrik.de/north-america/us-latest.osm.pbf"
)

URL="${REGION_URLS[$REGION]:-${REGION_URLS[india]}}"
PBF_FILE="$DATA_DIR/map.osm.pbf"

echo "======================================================"
echo " OSRM Map Setup: $REGION"
echo " URL: $URL"
echo "======================================================"

# Step 1: Download
if [ ! -f "$PBF_FILE" ]; then
  echo "📥 Downloading $REGION map data (this may take a while)..."
  wget -O "$PBF_FILE" "$URL"
  echo "✅ Download complete"
else
  echo "⏭️  Map file already exists, skipping download"
fi

# Step 2: Extract (uses OSRM Docker image)
echo "⚙️  Extracting routing graph..."
docker run --rm -v "$(pwd)/$DATA_DIR:/data" \
  osrm/osrm-backend:latest \
  osrm-extract -p /opt/car.lua /data/map.osm.pbf

# Step 3: Partition (MLD algorithm — best for dynamic updates)
echo "⚙️  Partitioning..."
docker run --rm -v "$(pwd)/$DATA_DIR:/data" \
  osrm/osrm-backend:latest \
  osrm-partition /data/map.osrm

# Step 4: Customize
echo "⚙️  Customizing..."
docker run --rm -v "$(pwd)/$DATA_DIR:/data" \
  osrm/osrm-backend:latest \
  osrm-customize /data/map.osrm

echo ""
echo "======================================================"
echo "✅ OSRM data ready in $DATA_DIR"
echo "   Start with: docker-compose up osrm"
echo "======================================================"
