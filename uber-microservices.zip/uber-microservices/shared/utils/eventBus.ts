// shared/utils/eventBus.ts

import { EventEmitter } from 'events';
import { ServiceEvent } from '../types';

class EventBus extends EventEmitter {
  private static instance: EventBus;

  private constructor() {
    super();
    this.setMaxListeners(50);
  }

  static getInstance(): EventBus {
    if (!EventBus.instance) {
      EventBus.instance = new EventBus();
    }
    return EventBus.instance;
  }

  publish<T>(event: string, payload: T, serviceOrigin: string): void {
    const envelope: ServiceEvent<T> = {
      event,
      payload,
      timestamp: new Date().toISOString(),
      serviceOrigin,
    };
    this.emit(event, envelope);
    this.emit('*', envelope); // wildcard listener for logging
  }

  subscribe<T>(event: string, handler: (envelope: ServiceEvent<T>) => void): void {
    this.on(event, handler);
  }

  unsubscribe(event: string, handler: (...args: unknown[]) => void): void {
    this.off(event, handler);
  }
}

export const eventBus = EventBus.getInstance();

// ─── Event name constants ────────────────────────────────────────────
export const EVENTS = {
  RIDE_BOOKED: 'ride.booked',
  RIDE_ACCEPTED: 'ride.accepted',
  RIDE_STARTED: 'ride.started',
  RIDE_COMPLETED: 'ride.completed',
  RIDE_CANCELLED: 'ride.cancelled',
  DRIVER_LOCATION_UPDATED: 'driver.location.updated',
  PAYMENT_COMPLETED: 'payment.completed',
  PAYMENT_FAILED: 'payment.failed',
} as const;
