// shared/utils/logger.ts

import winston from 'winston';

export const createLogger = (serviceName: string) => {
  return winston.createLogger({
    level: process.env.NODE_ENV === 'production' ? 'info' : 'debug',
    defaultMeta: { service: serviceName },
    format: winston.format.combine(
      winston.format.errors({ stack: true }),
      winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
      winston.format.printf(({ level, message, timestamp, service, stack, ...meta }) => {
        let msg = `${timestamp} [${service}] [${level}]: ${message}`;
        if (stack) msg += `\n${stack}`;
        if (Object.keys(meta).length) msg += ` | ${JSON.stringify(meta)}`;
        return msg;
      })
    ),
    transports: [
      new winston.transports.Console({
        format: winston.format.combine(
          winston.format.colorize(),
          winston.format.errors({ stack: true }),
          winston.format.timestamp({ format: 'HH:mm:ss' }),
          winston.format.printf(({ level, message, timestamp, service, stack }) => {
            let msg = `${timestamp} [${service}] ${level}: ${message}`;
            if (stack) msg += `\n${stack}`;
            return msg;
          })
        ),
      }),
    ],
  });
};
