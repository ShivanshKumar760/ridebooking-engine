// shared/middleware/auth.ts

import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { JwtPayload } from '../types';

declare global {
  namespace Express {
    interface Request {
      user?: JwtPayload;
    }
  }
}

export const authenticate = (req: Request, res: Response, next: NextFunction): void => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    res.status(401).json({ success: false, message: 'Access token required' });
    return;
  }
  try {
    const token = authHeader.split(' ')[1];
    req.user = jwt.verify(token, process.env.JWT_SECRET as string) as JwtPayload;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
};

export const requireRole = (...roles: ('passenger' | 'driver')[]) =>
  (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) { res.status(401).json({ success: false, message: 'Not authenticated' }); return; }
    if (!roles.includes(req.user.role)) {
      res.status(403).json({ success: false, message: `Required role: ${roles.join(' or ')}` });
      return;
    }
    next();
  };

export class AppError extends Error {
  constructor(public message: string, public statusCode: number) {
    super(message);
    this.name = 'AppError';
  }
}

export const errorHandler = (err: Error, _req: Request, res: Response, _next: NextFunction): void => {
  if (err instanceof AppError) {
    res.status(err.statusCode).json({ success: false, message: err.message });
    return;
  }
  const pgErr = err as { code?: string };
  if (pgErr.code === '23505') { res.status(409).json({ success: false, message: 'Already exists' }); return; }
  if (pgErr.code === '23503') { res.status(400).json({ success: false, message: 'Referenced record not found' }); return; }
  if (err.name === 'JsonWebTokenError') { res.status(401).json({ success: false, message: 'Invalid token' }); return; }
  if (err.name === 'TokenExpiredError') { res.status(401).json({ success: false, message: 'Token expired' }); return; }
  console.error('Unhandled error:', err);
  res.status(500).json({ success: false, message: process.env.NODE_ENV === 'production' ? 'Internal server error' : err.message });
};
