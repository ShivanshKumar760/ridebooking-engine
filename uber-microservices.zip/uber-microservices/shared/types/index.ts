// shared/types/index.ts

export interface GeoPoint {
  latitude: number;
  longitude: number;
}

export interface JwtPayload {
  userId: string;
  role: 'passenger' | 'driver';
  iat?: number;
  exp?: number;
}

export interface AuthTokens {
  accessToken: string;
  refreshToken: string;
}

export type VehicleType = 'bike' | 'auto' | 'cab' | 'premium';

export type RideStatus =
  | 'searching'
  | 'driver_assigned'
  | 'driver_arriving'
  | 'ride_started'
  | 'completed'
  | 'cancelled';

export type PaymentStatus = 'pending' | 'processing' | 'completed' | 'failed' | 'refunded';
export type PaymentGateway = 'razorpay' | 'stripe' | 'mock';

// ─── Inter-service events ────────────────────────────────────────────
export interface ServiceEvent<T = unknown> {
  event: string;
  payload: T;
  timestamp: string;
  serviceOrigin: string;
}

export interface RideBookedEvent {
  rideId: string;
  passengerId: string;
  passengerUserId: string;
  passengerName: string;
  passengerRating: number;
  passengerPhone: string;
  pickupLocation: GeoPoint;
  pickupAddress: string;
  dropoffLocation: GeoPoint;
  dropoffAddress: string;
  vehicleType: VehicleType;
  estimatedFare: number;
  distanceKm: number;
  routePolyline?: string;
  nearbyDriverUserIds: string[];
}

export interface RideAcceptedEvent {
  rideId: string;
  driverId: string;
  driverUserId: string;
  driverName: string;
  driverPhone: string;
  vehicleType: VehicleType;
  vehicleNumber: string;
  vehicleModel: string;
  driverRating: number;
  driverLocation: GeoPoint;
  otp: string;
  etaMinutes: number;
}

export interface RideStartedEvent {
  rideId: string;
  startedAt: string;
}

export interface RideCompletedEvent {
  rideId: string;
  finalFare: number;
  distanceKm: number;
  durationMinutes: number;
  completedAt: string;
}

export interface RideCancelledEvent {
  rideId: string;
  reason: string;
  cancelledBy: 'passenger' | 'driver' | 'system';
  driverId?: string;
}

export interface DriverLocationEvent {
  driverId: string;
  driverUserId: string;
  latitude: number;
  longitude: number;
  heading?: number;
  speed?: number;
  timestamp: string;
}

export interface PaymentCompletedEvent {
  rideId: string;
  transactionId: string;
  amount: number;
  gateway: PaymentGateway;
  paidAt: string;
}

// ─── OSRM types ──────────────────────────────────────────────────────
export interface OSRMRoute {
  distanceMeters: number;
  distanceKm: number;
  durationSeconds: number;
  durationMinutes: number;
  polyline: string;
  steps: OSRMStep[];
}

export interface OSRMStep {
  instruction: string;
  distanceMeters: number;
  durationSeconds: number;
  coordinates: [number, number];
}

export interface NearbyDriver {
  driverId: string;
  userId: string;
  name: string;
  phone: string;
  vehicleType: VehicleType;
  vehicleNumber: string;
  vehicleModel: string;
  rating: number;
  totalRides: number;
  latitude: number;
  longitude: number;
  distanceKm: number;
}
