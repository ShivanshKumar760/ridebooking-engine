// ride-service/src/index.ts

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import crypto from 'crypto';
import { createLogger } from '../../shared/utils/logger';
import { authenticate, requireRole, errorHandler, AppError } from '../../shared/middleware/auth';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import { withTransaction } from '../../shared/utils/database';
import {
  RideBookedEvent, RideCancelledEvent,
  GeoPoint, VehicleType,
} from '../../shared/types';

const logger = createLogger('ride-service');
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet()); app.use(cors()); app.use(compression()); app.use(express.json());

// ─── Inject user from gateway headers ───────────────────────────────
app.use((req: Request, _res: Response, next: NextFunction) => {
  const userId = req.headers['x-user-id'] as string;
  const role   = req.headers['x-user-role'] as string;
  if (userId && role) req.user = { userId, role: role as 'passenger' | 'driver' };
  next();
});

// ─── Internal auth (called by other services) ────────────────────────
const internalAuth = (req: Request, res: Response, next: NextFunction) => {
  const secret = req.headers['x-internal-secret'];
  if (secret !== (process.env.INTERNAL_SECRET || 'internal')) {
    return res.status(403).json({ success: false, message: 'Forbidden' });
  }
  next();
};

const generateOTP = () => Math.floor(100000 + Math.random() * 900000).toString();

app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'ride-service' }));

// ─── POST /api/rides/book ─────────────────────────────────────────────
app.post('/api/rides/book',
  authenticate, requireRole('passenger'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { pickupLocation, pickupAddress, dropoffLocation, dropoffAddress, vehicleType } = req.body as {
        pickupLocation: GeoPoint; pickupAddress: string;
        dropoffLocation: GeoPoint; dropoffAddress: string;
        vehicleType: VehicleType;
      };

      // Get passenger
      const { rows: [passenger] } = await pool.query(
        `SELECT p.id, u.name, u.phone, p.rating FROM passengers p JOIN users u ON p.user_id=u.id WHERE p.user_id=$1`,
        [userId]
      );
      if (!passenger) throw new AppError('Passenger not found', 404);

      // Check no active ride
      const { rows: active } = await pool.query(
        `SELECT id FROM rides WHERE passenger_id=$1 AND status IN ('searching','driver_assigned','driver_arriving','ride_started')`,
        [passenger.id]
      );
      if (active.length) throw new AppError('You already have an active ride', 409);

      // Get route from location service (includes OSRM)
      let distanceKm = 5; let estimatedFare = 100; let routePolyline = '';
      try {
        const locRes = await fetch(`${process.env.LOCATION_SERVICE_URL || 'http://localhost:3005'}/api/location/route`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'Authorization': req.headers.authorization || '' },
          body: JSON.stringify({ origin: pickupLocation, destination: dropoffLocation, vehicleType }),
        });
        if (locRes.ok) {
          const locData = await locRes.json() as { data: { route: { distanceKm: number; polyline: string }; estimatedFare: number } };
          distanceKm = locData.data.route.distanceKm;
          estimatedFare = locData.data.estimatedFare ?? 100;
          routePolyline = locData.data.route.polyline;
        }
      } catch { logger.warn('Location service unreachable, using defaults'); }

      const otp = generateOTP();

      const { rows: [ride] } = await pool.query(
        `INSERT INTO rides (
          passenger_id, pickup_latitude, pickup_longitude, pickup_address,
          dropoff_latitude, dropoff_longitude, dropoff_address,
          vehicle_type, estimated_fare, distance_km, otp, route_polyline, status
        ) VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,'searching') RETURNING *`,
        [
          passenger.id,
          pickupLocation.latitude, pickupLocation.longitude, pickupAddress,
          dropoffLocation.latitude, dropoffLocation.longitude, dropoffAddress,
          vehicleType, estimatedFare, distanceKm, otp, routePolyline,
        ]
      );

      // Find nearby drivers via location service
      let nearbyDriverUserIds: string[] = [];
      try {
        const nearbyRes = await fetch(
          `${process.env.LOCATION_SERVICE_URL || 'http://localhost:3005'}/api/location/drivers/nearby?` +
          `latitude=${pickupLocation.latitude}&longitude=${pickupLocation.longitude}&vehicleType=${vehicleType}&radius=8`,
          { headers: { 'Authorization': req.headers.authorization || '' } }
        );
        if (nearbyRes.ok) {
          const nearbyData = await nearbyRes.json() as { data: { drivers: Array<{ user_id: string }> } };
          nearbyDriverUserIds = nearbyData.data.drivers.map(d => d.user_id);
        }
      } catch { logger.warn('Could not fetch nearby drivers'); }

      // Publish event → gateway broadcasts RIDE_REQUEST to nearby drivers
      eventBus.publish<RideBookedEvent>(EVENTS.RIDE_BOOKED, {
        rideId: ride.id, passengerId: passenger.id, passengerUserId: userId,
        passengerName: passenger.name, passengerRating: passenger.rating,
        passengerPhone: passenger.phone,
        pickupLocation, pickupAddress, dropoffLocation, dropoffAddress,
        vehicleType, estimatedFare, distanceKm, routePolyline,
        nearbyDriverUserIds,
      }, 'ride-service');

      // Auto-cancel if no driver in 2 mins
      setTimeout(async () => {
        const { rows: [check] } = await pool.query(`SELECT status FROM rides WHERE id=$1`, [ride.id]);
        if (check?.status === 'searching') {
          await pool.query(`UPDATE rides SET status='cancelled', cancellation_reason='No driver found', cancelled_at=NOW() WHERE id=$1`, [ride.id]);
          eventBus.publish<RideCancelledEvent>(EVENTS.RIDE_CANCELLED, {
            rideId: ride.id, reason: 'No driver found', cancelledBy: 'system',
          }, 'ride-service');
        }
      }, 120000);

      logger.info(`Ride ${ride.id} booked. Notified ${nearbyDriverUserIds.length} drivers`);
      res.status(201).json({ success: true, data: { rideId: ride.id, estimatedFare, distanceKm, status: 'searching', routePolyline } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/rides/history ───────────────────────────────────────────
app.get('/api/rides/history',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId, role } = req.user!;
      const page = parseInt((req.query.page as string) || '1');
      const limit = parseInt((req.query.limit as string) || '10');
      const offset = (page - 1) * limit;
      const status = req.query.status as string | undefined;

      let profileId: string;
      let col: string;
      if (role === 'passenger') {
        const { rows: [p] } = await pool.query(`SELECT id FROM passengers WHERE user_id=$1`, [userId]);
        if (!p) throw new AppError('Not found', 404);
        profileId = p.id; col = 'passenger_id';
      } else {
        const { rows: [d] } = await pool.query(`SELECT id FROM drivers WHERE user_id=$1`, [userId]);
        if (!d) throw new AppError('Not found', 404);
        profileId = d.id; col = 'driver_id';
      }

      const params: unknown[] = [profileId];
      let where = `WHERE r.${col}=$1`;
      if (status) { params.push(status); where += ` AND r.status=$${params.length}`; }

      const { rows } = await pool.query(
        `SELECT r.id, r.status, r.vehicle_type, r.estimated_fare, r.final_fare,
                r.distance_km, r.duration_minutes, r.pickup_address, r.dropoff_address,
                r.payment_status, r.created_at, r.completed_at, r.route_polyline
         FROM rides r ${where}
         ORDER BY r.created_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`,
        [...params, limit, offset]
      );
      const { rows: [cnt] } = await pool.query(`SELECT COUNT(*) FROM rides r ${where}`, params);
      res.json({ success: true, data: { rides: rows, pagination: { total: parseInt(cnt.count), page, limit } } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/rides/:rideId ───────────────────────────────────────────
app.get('/api/rides/:rideId',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { rideId } = req.params;
      const { userId, role } = req.user!;

      const { rows: [ride] } = await pool.query(
        `SELECT r.*, p.user_id as passenger_user_id, d.user_id as driver_user_id,
                u_p.name as passenger_name, u_p.phone as passenger_phone,
                u_d.name as driver_name, u_d.phone as driver_phone,
                drv.vehicle_number, drv.vehicle_model, drv.rating as driver_rating
         FROM rides r
         JOIN passengers p ON r.passenger_id=p.id
         JOIN users u_p ON p.user_id=u_p.id
         LEFT JOIN drivers drv ON r.driver_id=drv.id
         LEFT JOIN users u_d ON drv.user_id=u_d.id
         WHERE r.id=$1`,
        [rideId]
      );
      if (!ride) throw new AppError('Ride not found', 404);

      const isPassenger = ride.passenger_user_id === userId;
      const isDriver    = ride.driver_user_id === userId;
      if (!isPassenger && !isDriver) throw new AppError('Access denied', 403);

      // Only show OTP to passenger when driver is assigned
      if (!isPassenger) delete ride.otp;

      res.json({ success: true, data: ride });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/rides/:rideId/cancel ───────────────────────────────────
app.post('/api/rides/:rideId/cancel',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId, role } = req.user!;
      const { rideId } = req.params;
      const { reason } = req.body;

      let profileId: string;
      let whereCol: string;
      if (role === 'passenger') {
        const { rows: [p] } = await pool.query(`SELECT id FROM passengers WHERE user_id=$1`, [userId]);
        if (!p) throw new AppError('Not found', 404);
        profileId = p.id; whereCol = 'passenger_id';
      } else {
        const { rows: [d] } = await pool.query(`SELECT id FROM drivers WHERE user_id=$1`, [userId]);
        if (!d) throw new AppError('Not found', 404);
        profileId = d.id; whereCol = 'driver_id';
      }

      const { rows: [ride] } = await pool.query(
        `UPDATE rides SET status='cancelled', cancellation_reason=$1, cancelled_at=NOW()
         WHERE id=$2 AND ${whereCol}=$3 AND status IN ('searching','driver_assigned','driver_arriving')
         RETURNING *`,
        [reason || 'Cancelled by user', rideId, profileId]
      );
      if (!ride) throw new AppError('Ride not found or cannot be cancelled', 404);

      eventBus.publish<RideCancelledEvent>(EVENTS.RIDE_CANCELLED, {
        rideId, reason: reason || 'Cancelled by user',
        cancelledBy: role, driverId: ride.driver_id,
      }, 'ride-service');

      res.json({ success: true, message: 'Ride cancelled' });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/rides/:rideId/rate ─────────────────────────────────────
app.post('/api/rides/:rideId/rate',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { rideId } = req.params;
      const { rating, comment } = req.body;

      const { rows: [ride] } = await pool.query(
        `SELECT r.*, p.user_id as passenger_user_id, d.user_id as driver_user_id
         FROM rides r JOIN passengers p ON r.passenger_id=p.id LEFT JOIN drivers d ON r.driver_id=d.id
         WHERE r.id=$1 AND r.status='completed'`,
        [rideId]
      );
      if (!ride) throw new AppError('Ride not found or not completed', 404);

      const isPassenger = ride.passenger_user_id === userId;
      const isDriver    = ride.driver_user_id === userId;
      if (!isPassenger && !isDriver) throw new AppError('Access denied', 403);

      const ratedUserId = isPassenger ? ride.driver_user_id : ride.passenger_user_id;

      await withTransaction(pool, async (client) => {
        await client.query(
          `INSERT INTO ratings (ride_id,rated_by,rated_user,rating,comment) VALUES($1,$2,$3,$4,$5) ON CONFLICT DO NOTHING`,
          [rideId, userId, ratedUserId, rating, comment]
        );
        if (isPassenger && ride.driver_id) {
          await client.query(
            `UPDATE drivers SET rating=(SELECT AVG(rt.rating)::DECIMAL(3,2) FROM ratings rt JOIN users u ON rt.rated_user=u.id JOIN drivers d ON u.id=d.user_id WHERE d.id=$1) WHERE id=$1`,
            [ride.driver_id]
          );
        } else {
          await client.query(
            `UPDATE passengers SET rating=(SELECT AVG(rating)::DECIMAL(3,2) FROM ratings WHERE rated_user=$1) WHERE user_id=$1`,
            [ratedUserId]
          );
        }
      });
      res.json({ success: true, message: 'Rating submitted' });
    } catch (e) { next(e); }
  }
);

// ─── INTERNAL endpoints (called by driver-service) ────────────────────
app.post('/internal/rides/:rideId/assign', internalAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rideId } = req.params;
    const { driverId } = req.body;
    const { rows: [ride] } = await pool.query(
      `UPDATE rides SET driver_id=$1, status='driver_assigned', updated_at=NOW() WHERE id=$2 AND status='searching' RETURNING *`,
      [driverId, rideId]
    );
    if (!ride) return res.status(409).json({ message: 'Ride not available' });
    res.json({ ride });
  } catch (e) { next(e); }
});

app.post('/internal/rides/:rideId/start', internalAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rideId } = req.params;
    const { driverId, otp } = req.body;
    const { rows: [ride] } = await pool.query(
      `SELECT * FROM rides WHERE id=$1 AND driver_id=$2 AND status='driver_assigned'`, [rideId, driverId]
    );
    if (!ride) return res.status(404).json({ message: 'Ride not found' });
    if (ride.otp !== otp) return res.status(400).json({ message: 'Invalid OTP' });
    await pool.query(`UPDATE rides SET status='ride_started', otp_verified=true, started_at=NOW() WHERE id=$1`, [rideId]);
    res.json({ success: true });
  } catch (e) { next(e); }
});

app.post('/internal/rides/:rideId/complete', internalAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { rideId } = req.params;
    const { driverId } = req.body;
    const { rows: [ride] } = await pool.query(
      `SELECT * FROM rides WHERE id=$1 AND driver_id=$2 AND status='ride_started'`, [rideId, driverId]
    );
    if (!ride) return res.status(404).json({ message: 'Ride not found' });

    // Get real route distance from location service
    let distanceKm = parseFloat(ride.distance_km) || 5;
    try {
      const locRes = await fetch(`${process.env.LOCATION_SERVICE_URL || 'http://localhost:3005'}/api/location/route`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-Internal-Secret': process.env.INTERNAL_SECRET || 'internal' },
        body: JSON.stringify({
          origin:      { latitude: ride.pickup_latitude,  longitude: ride.pickup_longitude },
          destination: { latitude: ride.dropoff_latitude, longitude: ride.dropoff_longitude },
          vehicleType: ride.vehicle_type,
        }),
      });
      if (locRes.ok) {
        const locData = await locRes.json() as { data: { route: { distanceKm: number } } };
        distanceKm = locData.data.route.distanceKm;
      }
    } catch { /* use stored estimate */ }

    const durationMinutes = Math.ceil((Date.now() - new Date(ride.started_at).getTime()) / 60000);
    const base = parseFloat(process.env.BASE_FARE || '50');
    const perKm = parseFloat(process.env.PER_KM_RATE || '12');
    const mult: Record<string, number> = { bike: 0.7, auto: 1.0, cab: 1.3, premium: 2.0 };
    const finalFare = Math.round((base + distanceKm * perKm) * (mult[ride.vehicle_type] || 1) * 100) / 100;

    await pool.query(
      `UPDATE rides SET status='completed', final_fare=$1, distance_km=$2, duration_minutes=$3, completed_at=NOW() WHERE id=$4`,
      [finalFare, distanceKm, durationMinutes, rideId]
    );
    await pool.query(`UPDATE passengers SET total_rides=total_rides+1 WHERE id=$1`, [ride.passenger_id]);

    res.json({ success: true, finalFare, distanceKm, durationMinutes });
  } catch (e) { next(e); }
});

app.get('/internal/rides/driver/:driverId', internalAuth, async (req: Request, res: Response, next: NextFunction) => {
  try {
    const { driverId } = req.params;
    const limit = parseInt((req.query.limit as string) || '10');
    const offset = parseInt((req.query.offset as string) || '0');
    const { rows } = await pool.query(
      `SELECT * FROM rides WHERE driver_id=$1 ORDER BY created_at DESC LIMIT $2 OFFSET $3`,
      [driverId, limit, offset]
    );
    const { rows: [cnt] } = await pool.query(`SELECT COUNT(*) FROM rides WHERE driver_id=$1`, [driverId]);
    res.json({ success: true, data: { rides: rows, total: parseInt(cnt.count) } });
  } catch (e) { next(e); }
});

app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT || '3003', 10);
app.listen(PORT, () => logger.info(`Ride service on :${PORT}`));
process.on('SIGTERM', () => pool.end().then(() => process.exit(0)));
