// ride-service/src/migrate.ts
import 'dotenv/config';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const run = async () => {
  await pool.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS passengers (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id UUID UNIQUE NOT NULL,
      rating DECIMAL(3,2) DEFAULT 5.00,
      total_rides INTEGER DEFAULT 0,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS drivers (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id UUID UNIQUE NOT NULL,
      vehicle_type VARCHAR(20) NOT NULL,
      vehicle_number VARCHAR(20) NOT NULL,
      vehicle_model VARCHAR(100) NOT NULL,
      rating DECIMAL(3,2) DEFAULT 5.00,
      total_rides INTEGER DEFAULT 0,
      is_available BOOLEAN DEFAULT false,
      created_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS rides (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      passenger_id UUID NOT NULL REFERENCES passengers(id),
      driver_id UUID REFERENCES drivers(id),
      pickup_latitude DECIMAL(10,8) NOT NULL,
      pickup_longitude DECIMAL(11,8) NOT NULL,
      pickup_address TEXT NOT NULL,
      dropoff_latitude DECIMAL(10,8) NOT NULL,
      dropoff_longitude DECIMAL(11,8) NOT NULL,
      dropoff_address TEXT NOT NULL,
      status VARCHAR(30) NOT NULL DEFAULT 'searching'
        CHECK (status IN ('searching','driver_assigned','driver_arriving','ride_started','completed','cancelled')),
      vehicle_type VARCHAR(20) NOT NULL,
      estimated_fare DECIMAL(10,2) NOT NULL,
      final_fare DECIMAL(10,2),
      distance_km DECIMAL(8,3),
      duration_minutes INTEGER,
      otp VARCHAR(6) NOT NULL,
      otp_verified BOOLEAN DEFAULT false,
      route_polyline TEXT,
      payment_status VARCHAR(20) DEFAULT 'pending'
        CHECK (payment_status IN ('pending','processing','completed','failed','refunded')),
      payment_id TEXT,
      payment_gateway VARCHAR(20),
      payment_method VARCHAR(50),
      started_at TIMESTAMPTZ,
      completed_at TIMESTAMPTZ,
      cancelled_at TIMESTAMPTZ,
      cancellation_reason TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS ratings (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      ride_id UUID NOT NULL REFERENCES rides(id),
      rated_by UUID NOT NULL,
      rated_user UUID NOT NULL,
      rating INTEGER NOT NULL CHECK (rating BETWEEN 1 AND 5),
      comment TEXT,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      UNIQUE(ride_id, rated_by)
    )
  `);

  await pool.query(`CREATE INDEX IF NOT EXISTS idx_rides_passenger ON rides(passenger_id)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_rides_driver ON rides(driver_id)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_rides_status ON rides(status)`);

  // Trigger
  await pool.query(`
    CREATE OR REPLACE FUNCTION update_updated_at()
    RETURNS TRIGGER AS $$
    BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
    $$ LANGUAGE plpgsql
  `);
  await pool.query(`
    DO $$ BEGIN
      IF NOT EXISTS (SELECT 1 FROM pg_trigger WHERE tgname='rides_updated_at') THEN
        CREATE TRIGGER rides_updated_at BEFORE UPDATE ON rides
        FOR EACH ROW EXECUTE FUNCTION update_updated_at();
      END IF;
    END $$
  `);

  console.log('✅ Ride service migrations complete');
  await pool.end();
};

run().catch((e) => { console.error(e); process.exit(1); });
