# 🚗 Uber Microservices Backend

Production-ready ride-hailing backend split into **7 independent microservices** with TypeScript, Express, PostgreSQL, Socket.IO real-time layer, and **OSRM** for actual road-based routing.

---

## 🏗️ Services

| Service | Port | Responsibility |
|---|---|---|
| **api-gateway** | 3000 | Single entry point — JWT auth, rate limiting, reverse proxy, Socket.IO hub |
| **auth-service** | 3001 | Register/login passengers & drivers, JWT tokens, profiles |
| **driver-service** | 3002 | Availability toggle, accept/start/complete rides |
| **ride-service** | 3003 | Book rides, OTP, cancellation, history, ratings |
| **payment-service** | 3004 | Razorpay / Stripe / Mock gateway integration |
| **location-service** | 3005 | OSRM routing, nearby driver search, GPS history |
| **notification-service** | 3006 | Event-driven notifications (push/SMS/email hooks) |

---

## 🗺️ OSRM Routing

The **location-service** uses [OSRM](http://project-osrm.org/) for real road-based routing:

| Feature | Endpoint |
|---|---|
| Route with polyline + steps | `POST /api/location/route` |
| ETA driver → pickup | `GET /api/location/eta` |
| Snap GPS to nearest road | `POST /api/location/snap` |
| Nearby drivers (Haversine + OSRM matrix) | `GET /api/location/drivers/nearby` |

### OSRM Setup (local, recommended)

```bash
# 1. Download and process map data (choose your region)
chmod +x scripts/setup-osrm.sh
./scripts/setup-osrm.sh india       # ~700MB download, ~5min processing
# Other options: mumbai, delhi, bangalore, uk, usa

# 2. Start OSRM container
docker-compose up -d osrm

# 3. Verify
curl "http://localhost:5000/route/v1/driving/72.8777,19.0760;73.8567,18.5204"
```

### OSRM Public Demo (no setup, rate-limited)

If no local OSRM is running, the location-service **automatically falls back** to `router.project-osrm.org`. Fine for development, not for production.

Set in `.env`:
```
OSRM_URL=http://router.project-osrm.org  # public demo
OSRM_URL=http://osrm:5000                # local docker (recommended)
```

---

## 🚀 Quick Start

### Option A — Docker Compose (recommended)

```bash
# 1. Clone and configure
git clone <repo>
cd uber-microservices
cp .env.example .env
# Edit .env with real secrets

# 2. Start databases
docker-compose up -d postgres

# 3. Set up OSRM (optional — skippable for dev)
./scripts/setup-osrm.sh india

# 4. Run all migrations
docker-compose --profile migrate run --rm migrate-all

# 5. Start all services
docker-compose up -d

# 6. Verify
curl http://localhost:3000/health
```

### Option B — Local Development

Run each service in its own terminal:

```bash
# Terminal 1 — shared setup (run once)
cd uber-microservices

# Terminal 2 — Auth
cd auth-service && npm install && npm run migrate && npm run dev

# Terminal 3 — Location
cd location-service && npm install && npm run migrate && npm run dev

# Terminal 4 — Ride
cd ride-service && npm install && npm run migrate && npm run dev

# Terminal 5 — Driver
cd driver-service && npm install && npm run dev

# Terminal 6 — Payment
cd payment-service && npm install && npm run migrate && npm run dev

# Terminal 7 — Notification
cd notification-service && npm install && npm run dev

# Terminal 8 — API Gateway (start last)
cd api-gateway && npm install && npm run dev
```

---

## 🔌 WebSocket (Socket.IO)

Connect to `ws://localhost:3000` — auth via `auth: { token: "<accessToken>" }`.

### Client → Server

| Event | Payload | Who sends |
|---|---|---|
| `UPDATE_LOCATION` | `{ latitude, longitude, heading?, speed? }` | Driver only |
| `JOIN_RIDE_ROOM` | `{ rideId }` | Passenger or Driver |
| `LEAVE_RIDE_ROOM` | `{ rideId }` | Either |

### Server → Client

| Event | Payload | Sent to |
|---|---|---|
| `RIDE_REQUEST` | `{ rideId, passenger, pickup, dropoff, estimatedFare, distanceKm, routePolyline }` | Nearby drivers |
| `DRIVER_ASSIGNED` | `{ driver, otp, etaMinutes, rideId }` | Passenger in ride room |
| `DRIVER_LOCATION` | `{ latitude, longitude, heading, speed, timestamp }` | Passengers in active ride |
| `RIDE_STARTED` | `{ rideId, startedAt }` | All in ride room |
| `RIDE_COMPLETED` | `{ rideId, finalFare, distanceKm, durationMinutes }` | All in ride room |
| `RIDE_CANCELLED` | `{ rideId, reason, cancelledBy }` | All in ride room |
| `NO_DRIVERS_FOUND` | `{ rideId }` | Passenger |

---

## 📡 REST API

All endpoints go through the API Gateway on port **3000**. Include `Authorization: Bearer <token>` for protected routes.

### Auth `/api/auth`

```
POST /api/auth/register/passenger   — Register passenger
POST /api/auth/register/driver      — Register driver
POST /api/auth/login                — Login (both roles)
POST /api/auth/refresh              — Refresh access token
POST /api/auth/logout               — Logout
GET  /api/auth/me                   — Get own profile
```

### Rides `/api/rides`

```
POST /api/rides/book                — Book a ride (passenger)
GET  /api/rides/history             — Ride history (both)
GET  /api/rides/:rideId             — Ride status
POST /api/rides/:rideId/cancel      — Cancel ride
POST /api/rides/:rideId/rate        — Submit rating
```

### Driver `/api/drivers`

```
PUT  /api/drivers/availability             — Toggle available/unavailable
POST /api/drivers/rides/:rideId/accept     — Accept ride request
POST /api/drivers/rides/:rideId/start      — Start ride (OTP verify)
POST /api/drivers/rides/:rideId/complete   — Complete ride
GET  /api/drivers/rides                    — Driver's ride history
```

### Location `/api/location`

```
PUT  /api/location/driver           — Update GPS position (driver)
GET  /api/location/drivers/nearby   — Find nearby available drivers
POST /api/location/route            — Get OSRM route + fare estimate
GET  /api/location/eta              — ETA driver → pickup
POST /api/location/snap             — Snap coordinate to road
GET  /api/location/driver/:id/history — GPS trail
```

### Payments `/api/payments`

```
POST /api/payments/rides/:rideId/order    — Create payment order
POST /api/payments/rides/:rideId/verify   — Verify Razorpay/Stripe payment
POST /api/payments/rides/:rideId/mock     — Complete mock payment
GET  /api/payments/rides/:rideId/status   — Payment status
POST /api/payments/webhooks/stripe        — Stripe webhook
```

---

## 💰 Fare Calculation

```
fare = (BASE_FARE + distance_km × PER_KM_RATE) × vehicle_multiplier
```

Distance comes from **OSRM** (real road distance), not straight-line.

| Vehicle | Multiplier |
|---|---|
| bike | 0.7× |
| auto | 1.0× |
| cab | 1.3× |
| premium | 2.0× |

---

## 🗄️ Databases

Each service owns its own PostgreSQL database (Database-per-Service pattern):

| Service | Database | Tables |
|---|---|---|
| auth-service | `uber_auth_db` | users, passengers, drivers |
| ride-service | `uber_ride_db` | rides, ratings |
| payment-service | `uber_payment_db` | payment_transactions |
| location-service | `uber_location_db` | drivers (location cols), driver_locations |

---

## 📨 Inter-Service Communication

```
auth-service   ──────────────────────────────────────────────────────────
                     JWT tokens (stateless — no service-to-service calls)

driver-service ──── HTTP → ride-service  (assign/start/complete ride)
               ──── HTTP → location-service (get ETA)

ride-service   ──── HTTP → location-service (get OSRM route on booking)

All services   ──── EventBus (in-process EventEmitter)
                    → api-gateway  (RIDE_BOOKED, RIDE_ACCEPTED, etc → Socket.IO)
                    → notification-service (all events → push/SMS)
```

**Production note**: Replace `EventBus` (`shared/utils/eventBus.ts`) with Redis pub/sub or RabbitMQ for true inter-process messaging.

---

## 🏭 Production Checklist

- [ ] Set strong `JWT_SECRET` (32+ random chars)
- [ ] Set `INTERNAL_SECRET` for service-to-service calls
- [ ] Run `./scripts/setup-osrm.sh` for your region
- [ ] Set `OSRM_URL=http://osrm:5000` (local container)
- [ ] Configure real `PAYMENT_GATEWAY=razorpay` or `stripe`
- [ ] Set `NODE_ENV=production` in all services
- [ ] Configure `ALLOWED_ORIGINS` to your domains
- [ ] Replace `EventBus` with Redis pub/sub for multi-instance deployments
- [ ] Add a Redis container and use `GEORADIUS` for driver search at scale
- [ ] Set up nginx/Caddy as reverse proxy with TLS in front of api-gateway
- [ ] Configure log shipping (Datadog / ELK stack)
- [ ] Set up health check monitoring per service

---

## 📁 Project Structure

```
uber-microservices/
├── shared/                          # Code shared across all services
│   ├── types/index.ts               # All TypeScript interfaces + event types
│   ├── utils/eventBus.ts            # In-process pub/sub event bus
│   ├── utils/logger.ts              # Winston logger factory
│   ├── utils/database.ts            # pg Pool factory + transaction helper
│   └── middleware/auth.ts           # JWT authenticate + requireRole + AppError
│
├── api-gateway/src/index.ts         # Reverse proxy + Socket.IO hub
├── auth-service/src/                # Register, login, JWT, profiles
├── driver-service/src/              # Availability, accept/start/complete
├── ride-service/src/                # Book, cancel, history, ratings, OTP
├── payment-service/src/             # Razorpay + Stripe + Mock
├── location-service/src/            # OSRM client, nearby search, GPS
│   └── osrm.ts                      # getRoute, getETA, snapToRoad, matrix
├── notification-service/src/        # Event listeners → push/SMS/email
│
├── scripts/
│   ├── setup-osrm.sh               # Download + pre-process OSRM map data
│   └── init-multiple-dbs.sh        # Postgres multi-DB init
│
├── Dockerfile                       # Single Dockerfile (ARG SERVICE=...)
├── docker-compose.yml               # All services + Postgres + OSRM
└── .env.example
```
