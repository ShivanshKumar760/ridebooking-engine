// location-service/src/osrm.ts

import { OSRMRoute, OSRMStep, GeoPoint } from '../../shared/types';

const OSRM_BASE = process.env.OSRM_URL || 'http://router.project-osrm.org';

interface OSRMRouteResponse {
  code: string;
  routes: Array<{
    distance: number;
    duration: number;
    geometry: string | { coordinates: [number, number][]; type: string };
    legs: Array<{
      steps: Array<{
        distance: number;
        duration: number;
        maneuver: { location: [number, number]; instruction?: string };
      }>;
    }>;
  }>;
  waypoints: Array<{
    location: [number, number];
    name: string;
    distance: number;
  }>;
}

interface OSRMNearestResponse {
  code: string;
  waypoints: Array<{
    location: [number, number];
    name: string;
    distance: number;
  }>;
}

interface OSRMTableResponse {
  code: string;
  durations: number[][];
  distances: number[][];
  sources: Array<{ location: [number, number]; name: string }>;
  destinations: Array<{ location: [number, number]; name: string }>;
}

// ─── Route between two points ─────────────────────────────────────────
export const getRoute = async (
  origin: GeoPoint,
  destination: GeoPoint,
  profile: 'driving' | 'walking' | 'cycling' = 'driving'
): Promise<OSRMRoute> => {
  const url = `${OSRM_BASE}/route/v1/${profile}/${origin.longitude},${origin.latitude};${destination.longitude},${destination.latitude}?overview=full&geometries=polyline&steps=true&annotations=false`;

  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`OSRM route request failed: ${response.status} ${response.statusText}`);
  }

  const data = await response.json() as OSRMRouteResponse;

  if (data.code !== 'Ok' || !data.routes?.length) {
    throw new Error(`OSRM returned no route: ${data.code}`);
  }

  const route = data.routes[0];
  const steps: OSRMStep[] = route.legs
    .flatMap(leg => leg.steps)
    .map(step => ({
      instruction: step.maneuver.instruction || '',
      distanceMeters: step.distance,
      durationSeconds: step.duration,
      coordinates: step.maneuver.location,
    }));

  return {
    distanceMeters: route.distance,
    distanceKm: parseFloat((route.distance / 1000).toFixed(3)),
    durationSeconds: route.duration,
    durationMinutes: Math.ceil(route.duration / 60),
    polyline: typeof route.geometry === 'string' ? route.geometry : '',
    steps,
  };
};

// ─── Snap a coordinate to the nearest road ───────────────────────────
export const snapToRoad = async (
  point: GeoPoint,
  profile: 'driving' | 'walking' | 'cycling' = 'driving'
): Promise<GeoPoint & { roadName: string; distanceFromRoad: number }> => {
  const url = `${OSRM_BASE}/nearest/v1/${profile}/${point.longitude},${point.latitude}?number=1`;

  const response = await fetch(url);
  if (!response.ok) throw new Error(`OSRM nearest request failed: ${response.status}`);

  const data = await response.json() as OSRMNearestResponse;
  if (data.code !== 'Ok' || !data.waypoints?.length) {
    throw new Error('OSRM nearest returned no waypoints');
  }

  const wp = data.waypoints[0];
  return {
    longitude: wp.location[0],
    latitude: wp.location[1],
    roadName: wp.name,
    distanceFromRoad: wp.distance,
  };
};

// ─── Duration/distance matrix (many-to-many) ─────────────────────────
export const getDistanceMatrix = async (
  sources: GeoPoint[],
  destinations: GeoPoint[],
  profile: 'driving' | 'walking' | 'cycling' = 'driving'
): Promise<{ durations: number[][]; distances: number[][] }> => {
  const allPoints = [...sources, ...destinations]
    .map(p => `${p.longitude},${p.latitude}`)
    .join(';');

  const srcIdxs = sources.map((_, i) => i).join(';');
  const dstIdxs = destinations.map((_, i) => sources.length + i).join(';');

  const url = `${OSRM_BASE}/table/v1/${profile}/${allPoints}?sources=${srcIdxs}&destinations=${dstIdxs}&annotations=duration,distance`;

  const response = await fetch(url);
  if (!response.ok) throw new Error(`OSRM table request failed: ${response.status}`);

  const data = await response.json() as OSRMTableResponse;
  if (data.code !== 'Ok') throw new Error(`OSRM table error: ${data.code}`);

  return {
    durations: data.durations,  // seconds
    distances: data.distances,  // meters
  };
};

// ─── ETA from driver to pickup point ─────────────────────────────────
export const getETA = async (
  driverLocation: GeoPoint,
  pickupLocation: GeoPoint
): Promise<{ etaMinutes: number; distanceKm: number }> => {
  const route = await getRoute(driverLocation, pickupLocation);
  return {
    etaMinutes: route.durationMinutes,
    distanceKm: route.distanceKm,
  };
};

// ─── Haversine fallback (when OSRM unavailable) ───────────────────────
export const haversineDistance = (a: GeoPoint, b: GeoPoint): number => {
  const R = 6371;
  const dLat = toRad(b.latitude - a.latitude);
  const dLon = toRad(b.longitude - a.longitude);
  const x =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.latitude)) * Math.cos(toRad(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x));
};

const toRad = (d: number) => (d * Math.PI) / 180;

// ─── Fare calculation ─────────────────────────────────────────────────
export const calculateFare = (
  distanceKm: number,
  vehicleType: 'bike' | 'auto' | 'cab' | 'premium'
): number => {
  const base = parseFloat(process.env.BASE_FARE || '50');
  const perKm = parseFloat(process.env.PER_KM_RATE || '12');
  const mult: Record<string, number> = { bike: 0.7, auto: 1.0, cab: 1.3, premium: 2.0 };
  return Math.round((base + distanceKm * perKm) * (mult[vehicleType] ?? 1.0) * 100) / 100;
};
