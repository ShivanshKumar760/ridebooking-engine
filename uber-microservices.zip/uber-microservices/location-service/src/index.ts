// location-service/src/index.ts

import 'dotenv/config';
import express, { Request, Response, NextFunction } from 'express';
import { Pool } from 'pg';
import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import { createLogger } from '../../shared/utils/logger';
import { authenticate, requireRole, errorHandler, AppError } from '../../shared/middleware/auth';
import { getRoute, getETA, snapToRoad, calculateFare, haversineDistance } from './osrm';
import { GeoPoint } from '../../shared/types';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import { DriverLocationEvent } from '../../shared/types';

const logger = createLogger('location-service');
const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL });

app.use(helmet()); app.use(cors()); app.use(compression()); app.use(express.json());

// ─── In-memory driver location cache (fast reads) ─────────────────────
// In production: use Redis GEORADIUS
const driverLocCache = new Map<string, {
  driverId: string; userId: string;
  latitude: number; longitude: number;
  heading?: number; speed?: number;
  vehicleType: string; isAvailable: boolean;
  updatedAt: number;
}>();

// ─── Health ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'location-service' }));

// ─── POST /api/location/route
// Get full OSRM route between two points
app.post('/api/location/route',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { origin, destination, vehicleType } = req.body as {
        origin: GeoPoint; destination: GeoPoint; vehicleType?: string;
      };
      if (!origin?.latitude || !origin?.longitude || !destination?.latitude || !destination?.longitude) {
        throw new AppError('origin and destination with lat/lon required', 400);
      }

      let route;
      try {
        route = await getRoute(origin, destination);
      } catch (err) {
        // OSRM unavailable — fall back to Haversine estimate
        logger.warn('OSRM unavailable, falling back to Haversine', { err });
        const distanceKm = haversineDistance(origin, destination);
        route = {
          distanceKm,
          distanceMeters: distanceKm * 1000,
          durationMinutes: Math.ceil((distanceKm / 25) * 60),
          durationSeconds: Math.ceil((distanceKm / 25) * 3600),
          polyline: '',
          steps: [],
        };
      }

      const fare = vehicleType
        ? calculateFare(route.distanceKm, vehicleType as 'bike' | 'auto' | 'cab' | 'premium')
        : null;

      res.json({ success: true, data: { route, estimatedFare: fare } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/location/eta
// ETA from driver to pickup
app.get('/api/location/eta',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { driverLat, driverLng, pickupLat, pickupLng } = req.query as Record<string, string>;
      const driverLocation = { latitude: parseFloat(driverLat), longitude: parseFloat(driverLng) };
      const pickupLocation = { latitude: parseFloat(pickupLat), longitude: parseFloat(pickupLng) };

      let eta;
      try {
        eta = await getETA(driverLocation, pickupLocation);
      } catch {
        const distKm = haversineDistance(driverLocation, pickupLocation);
        eta = { etaMinutes: Math.ceil((distKm / 25) * 60), distanceKm: distKm };
      }

      res.json({ success: true, data: eta });
    } catch (e) { next(e); }
  }
);

// ─── POST /api/location/snap
// Snap coordinates to nearest road
app.post('/api/location/snap',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { latitude, longitude } = req.body as GeoPoint;
      const snapped = await snapToRoad({ latitude, longitude });
      res.json({ success: true, data: snapped });
    } catch (e) { next(e); }
  }
);

// ─── PUT /api/location/driver
// Driver updates their location — stored in cache + DB history
app.put('/api/location/driver',
  authenticate,
  requireRole('driver'),
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { userId } = req.user!;
      const { latitude, longitude, heading, speed } = req.body;

      // Get driver record
      const { rows } = await pool.query(
        `SELECT d.id, d.vehicle_type, d.is_available FROM drivers d WHERE d.user_id=$1`,
        [userId]
      );
      if (!rows[0]) throw new AppError('Driver not found', 404);
      const driver = rows[0];

      // Update in DB
      await pool.query(
        `UPDATE drivers SET current_latitude=$1, current_longitude=$2, last_location_update=NOW() WHERE id=$3`,
        [latitude, longitude, driver.id]
      );

      // Store history
      await pool.query(
        `INSERT INTO driver_locations (driver_id,latitude,longitude,heading,speed) VALUES($1,$2,$3,$4,$5)`,
        [driver.id, latitude, longitude, heading ?? null, speed ?? null]
      );

      // Update in-memory cache
      const cached = driverLocCache.get(userId) ?? {
        driverId: driver.id, userId,
        latitude, longitude, heading, speed,
        vehicleType: driver.vehicle_type,
        isAvailable: driver.is_available,
        updatedAt: Date.now(),
      };
      cached.latitude = latitude;
      cached.longitude = longitude;
      cached.heading = heading;
      cached.speed = speed;
      cached.updatedAt = Date.now();
      driverLocCache.set(userId, cached);

      // Publish event for gateway → socket broadcast
      eventBus.publish<DriverLocationEvent>(EVENTS.DRIVER_LOCATION_UPDATED, {
        driverId: driver.id, driverUserId: userId,
        latitude, longitude, heading, speed,
        timestamp: new Date().toISOString(),
      }, 'location-service');

      res.json({ success: true, message: 'Location updated' });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/location/drivers/nearby
// Find available drivers within radius using Haversine SQL + OSRM matrix
app.get('/api/location/drivers/nearby',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { latitude, longitude, vehicleType, radius = '8' } = req.query as Record<string, string>;
      if (!latitude || !longitude) throw new AppError('latitude and longitude required', 400);

      const lat = parseFloat(latitude);
      const lng = parseFloat(longitude);
      const radiusKm = parseFloat(radius);

      // Haversine SQL to find candidates
      let queryStr = `
        SELECT d.id as driver_id, d.user_id, u.name, u.phone,
          d.vehicle_type, d.vehicle_number, d.vehicle_model,
          d.rating, d.total_rides,
          d.current_latitude as latitude, d.current_longitude as longitude,
          (6371 * acos(
            cos(radians($1)) * cos(radians(d.current_latitude)) *
            cos(radians(d.current_longitude) - radians($2)) +
            sin(radians($1)) * sin(radians(d.current_latitude))
          )) AS distance_km
        FROM drivers d
        JOIN users u ON d.user_id = u.id
        WHERE d.is_available = true
          AND d.current_latitude IS NOT NULL
          AND d.current_longitude IS NOT NULL
          AND u.is_active = true
          AND (6371 * acos(
            cos(radians($1)) * cos(radians(d.current_latitude)) *
            cos(radians(d.current_longitude) - radians($2)) +
            sin(radians($1)) * sin(radians(d.current_latitude))
          )) <= $3
      `;
      const params: unknown[] = [lat, lng, radiusKm];

      if (vehicleType) {
        params.push(vehicleType);
        queryStr += ` AND d.vehicle_type = $${params.length}`;
      }
      queryStr += ` ORDER BY distance_km ASC LIMIT 10`;

      const { rows: candidates } = await pool.query(queryStr, params);

      // Enrich with real OSRM driving durations when OSRM is available
      if (candidates.length > 0) {
        try {
          const { getDistanceMatrix } = await import('./osrm');
          const pickup: GeoPoint = { latitude: lat, longitude: lng };
          const driverPoints: GeoPoint[] = candidates.map(d => ({
            latitude: d.latitude, longitude: d.longitude,
          }));
          const matrix = await getDistanceMatrix(driverPoints, [pickup]);

          candidates.forEach((d, i) => {
            d.eta_minutes = Math.ceil((matrix.durations[i]?.[0] ?? 0) / 60);
            d.driving_distance_km = parseFloat(((matrix.distances[i]?.[0] ?? 0) / 1000).toFixed(2));
          });
        } catch {
          // OSRM unavailable — ETA stays undefined; clients show Haversine distance
          logger.warn('OSRM matrix request failed, skipping ETA enrichment');
        }
      }

      res.json({ success: true, data: { drivers: candidates, count: candidates.length } });
    } catch (e) { next(e); }
  }
);

// ─── GET /api/location/driver/:driverId/history ───────────────────────
app.get('/api/location/driver/:driverId/history',
  authenticate,
  async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { driverId } = req.params;
      const { limit = '50' } = req.query as Record<string, string>;
      const { rows } = await pool.query(
        `SELECT latitude,longitude,heading,speed,recorded_at
         FROM driver_locations WHERE driver_id=$1
         ORDER BY recorded_at DESC LIMIT $2`,
        [driverId, parseInt(limit)]
      );
      res.json({ success: true, data: rows });
    } catch (e) { next(e); }
  }
);

app.use((_req, res) => res.status(404).json({ success: false, message: 'Not found' }));
app.use(errorHandler);

const PORT = parseInt(process.env.PORT || '3005', 10);
app.listen(PORT, () => logger.info(`Location service on :${PORT} | OSRM: ${process.env.OSRM_URL || 'router.project-osrm.org (public)'}`));

process.on('SIGTERM', () => pool.end().then(() => process.exit(0)));
