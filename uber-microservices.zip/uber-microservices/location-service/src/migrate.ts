// location-service/src/migrate.ts
import 'dotenv/config';
import { Pool } from 'pg';

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const run = async () => {
  await pool.query(`CREATE EXTENSION IF NOT EXISTS "uuid-ossp"`);

  // Drivers table (location columns)
  await pool.query(`
    CREATE TABLE IF NOT EXISTS drivers (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      user_id UUID UNIQUE NOT NULL,
      vehicle_type VARCHAR(20) NOT NULL,
      vehicle_number VARCHAR(20) NOT NULL,
      vehicle_model VARCHAR(100) NOT NULL,
      license_number VARCHAR(50) NOT NULL,
      rating DECIMAL(3,2) DEFAULT 5.00,
      total_rides INTEGER DEFAULT 0,
      is_available BOOLEAN DEFAULT false,
      current_latitude DECIMAL(10,8),
      current_longitude DECIMAL(11,8),
      last_location_update TIMESTAMPTZ,
      created_at TIMESTAMPTZ DEFAULT NOW(),
      updated_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  // Location history
  await pool.query(`
    CREATE TABLE IF NOT EXISTS driver_locations (
      id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
      driver_id UUID NOT NULL REFERENCES drivers(id),
      latitude DECIMAL(10,8) NOT NULL,
      longitude DECIMAL(11,8) NOT NULL,
      heading DECIMAL(5,2),
      speed DECIMAL(6,2),
      recorded_at TIMESTAMPTZ DEFAULT NOW()
    )
  `);

  await pool.query(`CREATE INDEX IF NOT EXISTS idx_driver_locs_driver ON driver_locations(driver_id)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_driver_locs_time ON driver_locations(recorded_at DESC)`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_drivers_available ON drivers(is_available) WHERE is_available=true`);
  await pool.query(`CREATE INDEX IF NOT EXISTS idx_drivers_location ON drivers(current_latitude,current_longitude)`);

  console.log('✅ Location service migrations complete');
  await pool.end();
};

run().catch((e) => { console.error(e); process.exit(1); });
