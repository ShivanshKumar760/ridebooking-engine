// api-gateway/src/index.ts

import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import compression from 'compression';
import morgan from 'morgan';
import http from 'http';
import rateLimit from 'express-rate-limit';
import { createProxyMiddleware } from 'http-proxy-middleware';
import jwt from 'jsonwebtoken';
import { Server as SocketServer, Socket } from 'socket.io';
import { createLogger } from '../../shared/utils/logger';
import { JwtPayload } from '../../shared/types';
import { eventBus, EVENTS } from '../../shared/utils/eventBus';
import {
  DriverLocationEvent,
  RideAcceptedEvent,
  RideStartedEvent,
  RideCompletedEvent,
  RideCancelledEvent,
  RideBookedEvent,
} from '../../shared/types';

const logger = createLogger('api-gateway');
const app = express();
const httpServer = http.createServer(app);

// ─── Middleware ───────────────────────────────────────────────────────
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({
  origin: (process.env.ALLOWED_ORIGINS || 'http://localhost:3000').split(','),
  credentials: true,
}));
app.use(compression());
app.use(morgan('combined', { stream: { write: (m) => logger.http(m.trim()) } }));

// Raw body for Stripe webhooks
app.use((req, _res, next) => {
  if (req.path === '/api/payments/webhooks/stripe') return next();
  express.json({ limit: '10mb' })(req, _res, next);
});
app.use(express.urlencoded({ extended: true }));

// ─── Rate limits ──────────────────────────────────────────────────────
const globalLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 500 });
const authLimiter   = rateLimit({ windowMs: 15 * 60 * 1000, max: 30,
  message: { success: false, message: 'Too many auth attempts' } });
app.use(globalLimiter);

// ─── Service URLs ─────────────────────────────────────────────────────
const SERVICES = {
  AUTH:     process.env.AUTH_SERVICE_URL     || 'http://localhost:3001',
  DRIVER:   process.env.DRIVER_SERVICE_URL   || 'http://localhost:3002',
  RIDE:     process.env.RIDE_SERVICE_URL     || 'http://localhost:3003',
  PAYMENT:  process.env.PAYMENT_SERVICE_URL  || 'http://localhost:3004',
  LOCATION: process.env.LOCATION_SERVICE_URL || 'http://localhost:3005',
};

// ─── JWT auth middleware for gateway ─────────────────────────────────
const gatewayAuth = (req: express.Request, res: express.Response, next: express.NextFunction) => {
  const authHeader = req.headers.authorization;
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, message: 'Access token required' });
  }
  try {
    req.user = jwt.verify(authHeader.split(' ')[1], process.env.JWT_SECRET as string) as JwtPayload;
    next();
  } catch {
    res.status(401).json({ success: false, message: 'Invalid or expired token' });
  }
};

const proxyOpts = (target: string) => ({
  target,
  changeOrigin: true,
  on: {
    error: (err: Error, _req: express.Request, res: express.Response) => {
      logger.error(`Proxy error → ${target}`, { error: err.message });
      res.status(502).json({ success: false, message: `Service unavailable` });
    },
  },
});

// ─── Health ───────────────────────────────────────────────────────────
app.get('/health', (_req, res) => res.json({ status: 'ok', service: 'api-gateway', uptime: process.uptime() }));

// ─── Route → Auth service ─────────────────────────────────────────────
app.use('/api/auth', authLimiter, createProxyMiddleware(proxyOpts(SERVICES.AUTH)));

// ─── Route → Driver service ───────────────────────────────────────────
app.use('/api/drivers', gatewayAuth, createProxyMiddleware({
  ...proxyOpts(SERVICES.DRIVER),
  on: {
    proxyReq: (proxyReq, req: express.Request) => {
      if (req.user) {
        proxyReq.setHeader('X-User-Id', req.user.userId);
        proxyReq.setHeader('X-User-Role', req.user.role);
      }
    },
  },
}));

// ─── Route → Ride service ─────────────────────────────────────────────
app.use('/api/rides', gatewayAuth, createProxyMiddleware({
  ...proxyOpts(SERVICES.RIDE),
  on: {
    proxyReq: (proxyReq, req: express.Request) => {
      if (req.user) {
        proxyReq.setHeader('X-User-Id', req.user.userId);
        proxyReq.setHeader('X-User-Role', req.user.role);
      }
    },
  },
}));

// ─── Route → Payment service ──────────────────────────────────────────
app.use('/api/payments/webhooks', createProxyMiddleware(proxyOpts(SERVICES.PAYMENT)));
app.use('/api/payments', gatewayAuth, createProxyMiddleware({
  ...proxyOpts(SERVICES.PAYMENT),
  on: {
    proxyReq: (proxyReq, req: express.Request) => {
      if (req.user) {
        proxyReq.setHeader('X-User-Id', req.user.userId);
        proxyReq.setHeader('X-User-Role', req.user.role);
      }
    },
  },
}));

// ─── Route → Location service ─────────────────────────────────────────
app.use('/api/location', gatewayAuth, createProxyMiddleware(proxyOpts(SERVICES.LOCATION)));

// ─── API info ─────────────────────────────────────────────────────────
app.get('/api', (_req, res) => res.json({
  name: 'Uber Microservices API Gateway',
  version: '1.0.0',
  services: Object.keys(SERVICES),
}));

app.use((_req, res) => res.status(404).json({ success: false, message: 'Route not found' }));

// ─── Socket.IO — central real-time hub ───────────────────────────────
const io = new SocketServer(httpServer, {
  cors: { origin: (process.env.ALLOWED_ORIGINS || '').split(','), credentials: true },
  transports: ['websocket', 'polling'],
});

io.use((socket: Socket, next) => {
  const token = socket.handshake.auth.token || socket.handshake.headers.authorization?.split(' ')[1];
  if (!token) return next(new Error('Authentication required'));
  try {
    (socket as Socket & { user: JwtPayload }).user = jwt.verify(token, process.env.JWT_SECRET as string) as JwtPayload;
    next();
  } catch {
    next(new Error('Invalid token'));
  }
});

io.on('connection', (socket: Socket) => {
  const user = (socket as Socket & { user: JwtPayload }).user;
  logger.info(`Socket connected: ${user.userId} (${user.role})`);

  socket.join(`user:${user.userId}`);
  if (user.role === 'driver') socket.join(`driver:${user.userId}`);

  // Driver sends live GPS → broadcast to active ride room
  socket.on('UPDATE_LOCATION', (data: { latitude: number; longitude: number; heading?: number; speed?: number }) => {
    if (user.role !== 'driver') return;
    eventBus.publish<DriverLocationEvent>(EVENTS.DRIVER_LOCATION_UPDATED, {
      driverId: '',        // will be resolved by driver service
      driverUserId: user.userId,
      ...data,
      timestamp: new Date().toISOString(),
    }, 'socket');
  });

  socket.on('JOIN_RIDE_ROOM', ({ rideId }: { rideId: string }) => {
    socket.join(`ride:${rideId}`);
    socket.emit('JOINED_RIDE_ROOM', { rideId, success: true });
  });

  socket.on('LEAVE_RIDE_ROOM', ({ rideId }: { rideId: string }) => socket.leave(`ride:${rideId}`));
  socket.on('disconnect', () => logger.info(`Socket disconnected: ${user.userId}`));
});

// ─── Forward internal events → sockets ───────────────────────────────
eventBus.subscribe<RideBookedEvent>(EVENTS.RIDE_BOOKED, ({ payload }) => {
  payload.nearbyDriverUserIds.forEach((uid) => {
    io.to(`driver:${uid}`).emit('RIDE_REQUEST', {
      rideId: payload.rideId,
      passenger: { name: payload.passengerName, rating: payload.passengerRating, phone: payload.passengerPhone },
      pickup: { ...payload.pickupLocation, address: payload.pickupAddress },
      dropoff: { ...payload.dropoffLocation, address: payload.dropoffAddress },
      estimatedFare: payload.estimatedFare,
      distanceKm: payload.distanceKm,
      vehicleType: payload.vehicleType,
      routePolyline: payload.routePolyline,
    });
  });
});

eventBus.subscribe<RideAcceptedEvent>(EVENTS.RIDE_ACCEPTED, ({ payload }) => {
  io.to(`ride:${payload.rideId}`).emit('DRIVER_ASSIGNED', {
    driver: {
      driverId: payload.driverId,
      name: payload.driverName,
      phone: payload.driverPhone,
      vehicleType: payload.vehicleType,
      vehicleNumber: payload.vehicleNumber,
      vehicleModel: payload.vehicleModel,
      rating: payload.driverRating,
      latitude: payload.driverLocation.latitude,
      longitude: payload.driverLocation.longitude,
    },
    otp: payload.otp,
    etaMinutes: payload.etaMinutes,
    rideId: payload.rideId,
  });
});

eventBus.subscribe<RideStartedEvent>(EVENTS.RIDE_STARTED, ({ payload }) => {
  io.to(`ride:${payload.rideId}`).emit('RIDE_STARTED', payload);
});

eventBus.subscribe<RideCompletedEvent>(EVENTS.RIDE_COMPLETED, ({ payload }) => {
  io.to(`ride:${payload.rideId}`).emit('RIDE_COMPLETED', payload);
});

eventBus.subscribe<RideCancelledEvent>(EVENTS.RIDE_CANCELLED, ({ payload }) => {
  io.to(`ride:${payload.rideId}`).emit('RIDE_CANCELLED', payload);
});

eventBus.subscribe<DriverLocationEvent>(EVENTS.DRIVER_LOCATION_UPDATED, ({ payload }) => {
  // Broadcast driver location to any active ride room via ride service query
  // In production: ride service publishes rideId alongside driver location
  io.emit(`driver_loc:${payload.driverUserId}`, {
    latitude: payload.latitude,
    longitude: payload.longitude,
    heading: payload.heading,
    speed: payload.speed,
    timestamp: payload.timestamp,
  });
});

// ─── Start ────────────────────────────────────────────────────────────
const PORT = parseInt(process.env.PORT || '3000', 10);
httpServer.listen(PORT, () => {
  logger.info(`🚀 API Gateway running on port ${PORT}`);
});

process.on('SIGTERM', () => { httpServer.close(() => process.exit(0)); });
process.on('SIGINT',  () => { httpServer.close(() => process.exit(0)); });
