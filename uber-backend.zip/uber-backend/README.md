# 🚗 Uber Backend — Production-Ready API

A full-featured ride-hailing backend built with **TypeScript**, **Express**, **PostgreSQL**, and **Socket.IO**. Includes JWT auth, real-time geolocation, driver matching, OTP verification, and Razorpay/Stripe payment integration with mock fallback.

---

## 📐 Architecture Overview

```
┌──────────────────────────────────────────────────────────────┐
│                        Clients                               │
│         Passenger App          Driver App                    │
└────────────┬─────────────────────────┬────────────────────── ┘
             │  REST + WebSocket        │  REST + WebSocket
┌────────────▼─────────────────────────▼──────────────────────┐
│                    Express Server (Port 3000)                 │
│  ┌─────────────┐  ┌──────────────┐  ┌────────────────────┐  │
│  │  REST API   │  │  Socket.IO   │  │  Rate Limiter /    │  │
│  │  Routes     │  │  Real-time   │  │  Helmet / CORS     │  │
│  └──────┬──────┘  └──────┬───────┘  └────────────────────┘  │
│         │                │                                    │
│  ┌──────▼──────────────────────────┐                         │
│  │         Controllers             │                         │
│  │  Auth │ Ride │ Driver │ Payment │                         │
│  └──────┬──────────────────────────┘                         │
│         │                                                     │
│  ┌──────▼──────────────────────────┐                         │
│  │         Services                │                         │
│  │  PaymentService (Razorpay /     │                         │
│  │  Stripe / Mock)                 │                         │
│  └──────┬──────────────────────────┘                         │
│         │                                                     │
│  ┌──────▼──────────────────────────┐                         │
│  │      PostgreSQL (via pg Pool)   │                         │
│  │  users │ drivers │ passengers   │                         │
│  │  rides │ payments │ ratings     │                         │
│  └─────────────────────────────────┘                         │
└──────────────────────────────────────────────────────────────┘
```

---

## 🚀 Quick Start

### Prerequisites
- Node.js 20+
- PostgreSQL 14+
- npm or yarn

### 1. Clone & Install

```bash
git clone <repo>
cd uber-backend
npm install
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your values
```

### 3. Run Migrations

```bash
npm run migrate
```

### 4. Start Development Server

```bash
npm run dev
```

### Docker (Recommended)

```bash
# Start Postgres + API
docker-compose up -d postgres
docker-compose --profile migrate run migrate   # run once
docker-compose up -d api

# Or all at once (starts postgres, runs migrations, starts api)
docker-compose up --build
```

---

## 🔑 Environment Variables

| Variable | Description | Default |
|---|---|---|
| `PORT` | Server port | `3000` |
| `DATABASE_URL` | PostgreSQL connection string | — |
| `JWT_SECRET` | Access token secret (32+ chars) | — |
| `JWT_REFRESH_SECRET` | Refresh token secret | — |
| `JWT_EXPIRES_IN` | Access token TTL | `1h` |
| `JWT_REFRESH_EXPIRES_IN` | Refresh token TTL | `7d` |
| `PAYMENT_GATEWAY` | `razorpay` \| `stripe` \| `mock` | `mock` |
| `RAZORPAY_KEY_ID` | Razorpay key ID | — |
| `RAZORPAY_KEY_SECRET` | Razorpay key secret | — |
| `STRIPE_SECRET_KEY` | Stripe secret key | — |
| `STRIPE_WEBHOOK_SECRET` | Stripe webhook signing secret | — |
| `BASE_FARE` | Base fare in INR | `50` |
| `PER_KM_RATE` | Per km rate in INR | `12` |
| `ALLOWED_ORIGINS` | Comma-separated allowed CORS origins | — |

---

## 📡 REST API Reference

All endpoints are prefixed with `/api`. Auth endpoints require `Authorization: Bearer <token>` unless noted.

---

### 🔐 Auth  `/api/auth`

#### `POST /api/auth/register/passenger`
Register a new passenger.

**Body:**
```json
{
  "email": "jane@example.com",
  "phone": "+919876543210",
  "name": "Jane Doe",
  "password": "Password123"
}
```

**Response `201`:**
```json
{
  "success": true,
  "data": {
    "user": { "id": "uuid", "email": "...", "role": "passenger" },
    "accessToken": "eyJ...",
    "refreshToken": "eyJ..."
  }
}
```

---

#### `POST /api/auth/register/driver`
Register a new driver.

**Body:**
```json
{
  "email": "ravi@example.com",
  "phone": "+919876543211",
  "name": "Ravi Kumar",
  "password": "Password123",
  "vehicleType": "cab",
  "vehicleNumber": "MH12AB1234",
  "vehicleModel": "Swift Dzire",
  "licenseNumber": "MH0120210012345"
}
```

Vehicle types: `bike` | `auto` | `cab` | `premium`

---

#### `POST /api/auth/login`
```json
{ "email": "jane@example.com", "password": "Password123" }
```

---

#### `POST /api/auth/refresh`
```json
{ "refreshToken": "eyJ..." }
```

---

#### `POST /api/auth/logout` 🔒
Invalidates refresh token.

---

#### `GET /api/auth/me` 🔒
Returns full profile for current user (includes driver or passenger details).

---

### 🚕 Rides  `/api/rides`

#### `POST /api/rides/book` 🔒 (passenger only)
Book a new ride.

**Body:**
```json
{
  "pickupLocation": { "latitude": 18.5204, "longitude": 73.8567 },
  "pickupAddress": "Shivajinagar, Pune",
  "dropoffLocation": { "latitude": 18.6298, "longitude": 73.7997 },
  "dropoffAddress": "Pimpri, Pune",
  "vehicleType": "cab"
}
```

**Response `201`:**
```json
{
  "success": true,
  "data": {
    "rideId": "uuid",
    "estimatedFare": 127.40,
    "distanceKm": 12.5,
    "nearbyDriversCount": 3,
    "status": "searching"
  }
}
```

Nearby drivers are automatically notified via Socket.IO. If no driver accepts within **2 minutes**, the ride is auto-cancelled.

---

#### `GET /api/rides/history` 🔒
Returns paginated ride history for both passengers and drivers.

Query params: `page`, `limit`, `status`

---

#### `GET /api/rides/:rideId` 🔒
Get full ride status including driver location if assigned.

---

#### `POST /api/rides/:rideId/cancel` 🔒
Cancel an active ride.

```json
{ "reason": "Changed my mind" }
```

Passengers can cancel rides in `searching` or `driver_assigned` status. Drivers can cancel `driver_assigned` rides.

---

#### `POST /api/rides/:rideId/rate` 🔒
Submit a rating after ride completion.

```json
{ "rating": 5, "comment": "Great driver!" }
```

---

### 🧑‍✈️ Driver  `/api/drivers`

#### `PUT /api/drivers/location` 🔒 (driver only)
Update driver GPS location.

```json
{
  "latitude": 18.5204,
  "longitude": 73.8567,
  "heading": 270.5,
  "speed": 35.0
}
```

---

#### `PUT /api/drivers/availability` 🔒 (driver only)
Toggle availability.

```json
{ "isAvailable": true }
```

---

#### `GET /api/drivers/nearby` 🔒 (passenger only)
Search for available drivers.

Query params: `latitude`, `longitude`, `vehicleType` (optional), `radius` (km, default 5)

---

#### `POST /api/drivers/rides/:rideId/accept` 🔒 (driver only)
Accept a ride request. Notifies the passenger via Socket.IO with driver details and OTP.

---

#### `POST /api/drivers/rides/:rideId/start` 🔒 (driver only)
Start the ride after OTP verification.

```json
{ "otp": "847291" }
```

---

#### `POST /api/drivers/rides/:rideId/complete` 🔒 (driver only)
Mark ride as complete. Calculates final fare and duration.

---

### 💳 Payments  `/api/payments`

#### `POST /api/payments/rides/:rideId/order` 🔒 (passenger only)
Create payment order. Uses configured gateway (`PAYMENT_GATEWAY` env var); falls back to mock on error.

**Response:**
```json
{
  "data": {
    "orderId": "ride-uuid",
    "amount": 127.40,
    "currency": "INR",
    "gateway": "razorpay",
    "gatewayOrderId": "order_xxxx"
  }
}
```

---

#### `POST /api/payments/rides/:rideId/verify` 🔒 (passenger only)
Verify gateway payment after client-side completion.

```json
{
  "gatewayOrderId": "order_xxxx",
  "gatewayPaymentId": "pay_xxxx",
  "gatewaySignature": "hmac_sig",
  "gateway": "razorpay"
}
```

---

#### `POST /api/payments/rides/:rideId/mock` 🔒 (passenger only)
Complete payment using mock gateway (for testing / fallback).

---

#### `GET /api/payments/rides/:rideId/status` 🔒
Get payment status for a ride.

---

#### `POST /api/payments/webhooks/stripe`
Stripe webhook endpoint (no auth, uses signature verification).

---

## 🔌 WebSocket Events

Connect: `ws://localhost:3000` with `auth: { token: "<accessToken>" }`

### Client → Server

| Event | Payload | Description |
|---|---|---|
| `UPDATE_LOCATION` | `{ latitude, longitude, heading?, speed? }` | Driver sends GPS update |
| `JOIN_RIDE_ROOM` | `{ rideId }` | Join real-time ride channel |
| `LEAVE_RIDE_ROOM` | `{ rideId }` | Leave ride channel |
| `ACCEPT_RIDE` | `{ rideId }` | Driver accepts ride via socket |

### Server → Client

| Event | Payload | Description |
|---|---|---|
| `RIDE_REQUEST` | `{ rideId, passenger, pickup, dropoff, estimatedFare, distanceKm }` | Sent to nearby drivers when ride is booked |
| `DRIVER_ASSIGNED` | `{ driver, otp, eta_minutes, rideId }` | Sent to passenger when driver accepts |
| `DRIVER_LOCATION` | `{ driverId, latitude, longitude, heading, speed, timestamp }` | Live driver GPS during ride |
| `RIDE_STARTED` | `{ rideId, started_at }` | OTP verified, ride in progress |
| `RIDE_COMPLETED` | `{ rideId, final_fare, distance_km, duration_minutes }` | Ride finished |
| `RIDE_CANCELLED` | `{ rideId, reason, cancelled_by }` | Ride cancelled by either party |
| `NO_DRIVERS_FOUND` | `{ rideId }` | No driver accepted in 2 minutes |

### Socket.IO Client Example (JavaScript)

```javascript
import { io } from 'socket.io-client';

const socket = io('http://localhost:3000', {
  auth: { token: accessToken }
});

// Passenger: book ride then listen
socket.emit('JOIN_RIDE_ROOM', { rideId });
socket.on('DRIVER_ASSIGNED', ({ driver, otp, eta_minutes }) => {
  console.log(`Driver ${driver.name} is coming! OTP: ${otp}`);
});
socket.on('DRIVER_LOCATION', (loc) => {
  updateMapMarker(loc.latitude, loc.longitude);
});

// Driver: send location every 5 seconds
setInterval(() => {
  navigator.geolocation.getCurrentPosition(({ coords }) => {
    socket.emit('UPDATE_LOCATION', {
      latitude: coords.latitude,
      longitude: coords.longitude,
      heading: coords.heading,
      speed: coords.speed,
    });
  });
}, 5000);
```

---

## 🗄️ Database Schema

```
users          — shared auth table (passengers + drivers)
passengers     — passenger profile + rating
drivers        — driver profile, vehicle info, location
rides          — full ride lifecycle
driver_locations — GPS history trail
ratings        — mutual ratings after rides
payment_transactions — payment audit log
```

---

## 💰 Fare Calculation

```
fare = (BASE_FARE + distance_km × PER_KM_RATE) × vehicle_multiplier
```

| Vehicle | Multiplier |
|---|---|
| bike | 0.7× |
| auto | 1.0× |
| cab | 1.3× |
| premium | 2.0× |

---

## 🏗️ Production Checklist

- [ ] Set strong `JWT_SECRET` and `JWT_REFRESH_SECRET` (32+ random chars)
- [ ] Configure real `PAYMENT_GATEWAY` (`razorpay` or `stripe`)
- [ ] Enable SSL/TLS (via reverse proxy: nginx/Caddy)
- [ ] Set `NODE_ENV=production`
- [ ] Configure `ALLOWED_ORIGINS` to your domain(s)
- [ ] Set up log aggregation (e.g. Datadog, Logtail)
- [ ] Run `npm run migrate` before first deploy
- [ ] Set up DB connection pooling/PgBouncer for high load
- [ ] Configure Stripe webhook endpoint in Stripe Dashboard

---

## 📁 Project Structure

```
src/
├── config/
│   ├── database.ts       — pg Pool, query helper, transactions
│   └── migrate.ts        — DB migrations runner
├── controllers/
│   ├── authController.ts
│   ├── driverController.ts
│   ├── rideController.ts
│   └── paymentController.ts
├── middleware/
│   ├── auth.ts           — JWT authenticate + requireRole
│   ├── errorHandler.ts   — AppError + global handler
│   └── validate.ts       — express-validator wrapper
├── routes/
│   ├── authRoutes.ts
│   ├── rideRoutes.ts
│   ├── driverRoutes.ts
│   └── paymentRoutes.ts
├── services/
│   └── paymentService.ts — Razorpay + Stripe + Mock
├── socket/
│   └── socketServer.ts   — Socket.IO server + events
├── types/
│   └── index.ts          — All TypeScript interfaces
├── utils/
│   ├── geo.ts            — Haversine, fare calc, nearby SQL
│   ├── helpers.ts        — JWT, bcrypt, OTP utilities
│   └── logger.ts         — Winston logger
├── app.ts                — Express app setup
└── index.ts              — Server entry point
```
